plugins {
    id("com.android.application")
}

android {
    namespace = "com.drtv.player"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.drtv.premium"
        minSdk = 23
        targetSdk = 35
        versionCode = 5
        versionName = "3.0.1-premium-fix"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    val media3 = "1.11.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-exoplayer-dash:$media3")
    implementation("androidx.media3:media3-ui:$media3")
}
