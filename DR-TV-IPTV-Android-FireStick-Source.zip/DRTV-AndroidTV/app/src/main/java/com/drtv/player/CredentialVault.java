package com.drtv.player;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Keeps opt-in credentials encrypted with a non-exportable Android Keystore AES key.
 *  The encryption key is not included in GitHub, assets, or application backups.
 */
final class CredentialVault {
    private static final String KEY_ALIAS = "drtv.remember.login.v4";
    private static final String STORAGE = "drtv_secret_store";
    private final SharedPreferences prefs;

    CredentialVault(Context ctx) { prefs = ctx.getSharedPreferences(STORAGE, Context.MODE_PRIVATE); }

    boolean hasSavedLogin() { return prefs.contains("payload"); }

    void save(String server, String username, String password) throws Exception {
        JSONObject data = new JSONObject();
        data.put("server", server);
        data.put("user", username);
        data.put("password", password);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
        byte[] encrypted = cipher.doFinal(data.toString().getBytes(StandardCharsets.UTF_8));
        prefs.edit().putString("iv", Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP))
            .putString("payload", Base64.encodeToString(encrypted, Base64.NO_WRAP)).apply();
    }

    XtreamClient.Login read() {
        String iv = prefs.getString("iv", null);
        String value = prefs.getString("payload", null);
        if (iv == null || value == null) return null;
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(),
                new GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)));
            String json = new String(cipher.doFinal(Base64.decode(value, Base64.NO_WRAP)), StandardCharsets.UTF_8);
            JSONObject data = new JSONObject(json);
            return XtreamClient.credentials(data.getString("server"),
                data.getString("user"), data.getString("password"));
        } catch (Exception ignored) {
            clear();
            return null;
        }
    }

    void clear() { prefs.edit().remove("iv").remove("payload").apply(); }

    private static SecretKey getOrCreateKey() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        KeyStore.Entry entry = store.getEntry(KEY_ALIAS, null);
        if (entry instanceof KeyStore.SecretKeyEntry) return ((KeyStore.SecretKeyEntry) entry).getSecretKey();
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build());
        return generator.generateKey();
    }
}
