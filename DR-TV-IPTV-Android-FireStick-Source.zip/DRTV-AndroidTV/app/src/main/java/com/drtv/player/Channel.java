package com.drtv.player;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** Immutable IPTV channel or video item from an M3U playlist. */
public final class Channel {
    public final String name;
    public final String streamUrl;
    public final String group;
    public final String logoUrl;
    public final String tvgId;
    public final String key;

    public Channel(String name, String streamUrl, String group, String logoUrl, String tvgId) {
        this.name = name;
        this.streamUrl = streamUrl;
        this.group = group == null || group.trim().isEmpty() ? "Other" : group.trim();
        this.logoUrl = logoUrl == null ? "" : logoUrl;
        this.tvgId = tvgId == null ? "" : tvgId;
        this.key = hash(streamUrl);
    }

    private static String hash(String value) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256")
                    .digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b & 0xff));
            return sb.toString();
        } catch (NoSuchAlgorithmException ex) {
            return Integer.toHexString(value.hashCode());
        }
    }
}
