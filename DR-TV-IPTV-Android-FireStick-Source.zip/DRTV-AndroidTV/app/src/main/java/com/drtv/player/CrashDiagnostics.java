package com.drtv.player;

import android.content.Context;
import android.content.SharedPreferences;

/** Privacy-safe on-device crash information: no URLs, credentials or exception messages. */
final class CrashDiagnostics {
    private static final String STORE = "drtv_crash_diag";
    private static final String KEY = "last";
    private static boolean installed;
    private CrashDiagnostics() { }

    static synchronized void install(Context context) {
        if (installed) return;
        installed = true;
        final Context app = context.getApplicationContext();
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try {
                StringBuilder safe = new StringBuilder();
                safe.append(error.getClass().getSimpleName()).append("\n");
                StackTraceElement[] elements = error.getStackTrace();
                for (int i = 0; i < Math.min(8, elements.length); i++) {
                    StackTraceElement element = elements[i];
                    safe.append(element.getClassName()).append("#")
                        .append(element.getMethodName()).append(":")
                        .append(element.getLineNumber()).append("\n");
                }
                app.getSharedPreferences(STORE, Context.MODE_PRIVATE).edit()
                    .putString(KEY, safe.toString()).commit();
            } catch (Throwable ignored) { }
            if (previous != null) previous.uncaughtException(thread, error);
        });
    }

    static boolean hasReport(Context context) {
        return !getReport(context).isEmpty();
    }
    static String getReport(Context context) {
        return prefs(context).getString(KEY, "");
    }
    static void clear(Context context) {
        prefs(context).edit().remove(KEY).apply();
    }
    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(STORE, Context.MODE_PRIVATE);
    }
}
