package com.drtv.player;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Parser for extended M3U files. No IPTV provider or channel catalog is bundled. */
public final class PlaylistParser {
    private static final int MAX_CHANNELS = 20_000;
    private static final int MAX_LINE = 32_768;
    private static final Pattern ATTRIBUTE = Pattern.compile("([A-Za-z0-9_-]+)\\s*=\\s*\"([^\"]*)\"");

    private PlaylistParser() {}

    public static List<Channel> parse(BufferedReader reader, String baseUrl) throws IOException {
        List<Channel> output = new ArrayList<>();
        String currentName = "";
        String currentGroup = "";
        String currentLogo = "";
        String currentId = "";
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.length() > MAX_LINE) throw new IOException("Playlist has an excessively long line");
            line = line.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("#EXTINF")) {
                currentName = "";
                currentGroup = "";
                currentLogo = "";
                currentId = "";
                Matcher matcher = ATTRIBUTE.matcher(line);
                while (matcher.find()) {
                    String key = matcher.group(1).toLowerCase(Locale.ROOT);
                    String value = matcher.group(2);
                    switch (key) {
                        case "group-title": currentGroup = value; break;
                        case "tvg-logo": currentLogo = value; break;
                        case "tvg-id": currentId = value; break;
                        default: break;
                    }
                }
                // In extended M3U the display name follows the first unquoted comma.
                boolean quoted = false;
                int comma = -1;
                for (int i = 0; i < line.length(); i++) {
                    char c = line.charAt(i);
                    if (c == '"') quoted = !quoted;
                    if (c == ',' && !quoted && comma < 0) comma = i;
                }
                if (comma >= 0) currentName = line.substring(comma + 1).trim();
            } else if (line.startsWith("#EXTGRP:")) {
                currentGroup = line.substring(8).trim();
            } else if (!line.startsWith("#")) {
                String resolved = resolveUrl(baseUrl, line);
                if (resolved != null) {
                    String name = currentName.isEmpty() ? "Channel " + (output.size() + 1) : currentName;
                    output.add(new Channel(name, resolved, currentGroup, currentLogo, currentId));
                    if (output.size() >= MAX_CHANNELS) break;
                }
                currentName = "";
                currentGroup = "";
                currentLogo = "";
                currentId = "";
            }
        }
        return output;
    }

    /** Reject dangerous schemes; permit absolute HTTP(S) streams and remote relative URLs. */
    private static String resolveUrl(String base, String candidate) {
        try {
            URI uri = new URI(candidate);
            if (!uri.isAbsolute() && base != null && !base.isEmpty()) {
                uri = new URI(base).resolve(uri);
            }
            String scheme = uri.getScheme();
            if (scheme == null || uri.getHost() == null) return null;
            if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) return null;
            return uri.toString();
        } catch (Exception ignored) {
            return null;
        }
    }
}
