package com.drtv.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * DR TV MVP: remote-first Android / Fire TV M3U IPTV player.
 * No channels, service credentials or copyrighted content are distributed by the app.
 */
public final class MainActivity extends Activity {
    private static final int PICK_M3U = 42;
    private static final int BACKGROUND = Color.rgb(11, 12, 17);
    private static final int PANEL = Color.rgb(22, 24, 31);
    private static final int PANEL_ALT = Color.rgb(30, 32, 40);
    private static final int ACCENT = Color.rgb(231, 49, 65);
    private static final int WHITE = Color.rgb(249, 249, 251);
    private static final int MUTED = Color.rgb(164, 167, 180);
    private static final String PREFS = "drtv_playlist";

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final List<Channel> allChannels = new ArrayList<>();
    private final List<Channel> shownChannels = new ArrayList<>();
    private final List<String> groups = new ArrayList<>();
    private final Set<String> favouriteKeys = new HashSet<>();

    private SharedPreferences preferences;
    private ExoPlayer player;
    private PlayerView playerView;
    private LinearLayout page;
    private LinearLayout header;
    private LinearLayout browseRow;
    private LinearLayout groupPanel;
    private LinearLayout channelPanel;
    private LinearLayout playerPanel;
    private LinearLayout playerButtons;
    private TextView appSubtitle;
    private TextView titleNow;
    private TextView status;
    private TextView placeholder;
    private TextView footer;
    private TextView favouriteButton;
    private TextView fullscreenButton;
    private EditText search;
    private ListView groupList;
    private ListView channelList;
    private CategoryAdapter categoryAdapter;
    private ChannelAdapter channelAdapter;
    private String chosenGroup = "All channels";
    private Channel selected;
    private boolean fullScreen = false;
    private int loadGeneration = 0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        Set<String> saved = preferences.getStringSet("favourites", Collections.emptySet());
        if (saved != null) favouriteKeys.addAll(saved);

        player = new ExoPlayer.Builder(this).build();
        player.addListener(new Player.Listener() {
            @Override public void onPlayerError(PlaybackException error) {
                status.setText("Can't play this stream: " + error.getErrorCodeName());
                placeholder.setText("STREAM ERROR");
                placeholder.setVisibility(View.VISIBLE);
            }
            @Override public void onPlaybackStateChanged(int state) {
                if (selected == null) return;
                if (state == Player.STATE_BUFFERING) status.setText("Connecting / buffering…");
                else if (state == Player.STATE_READY) {
                    status.setText("Now playing  •  " + selected.group);
                    placeholder.setVisibility(View.GONE);
                } else if (state == Player.STATE_ENDED) status.setText("Playback ended");
            }
        });
        buildLayout();
        String type = preferences.getString("source_type", "demo");
        String source = preferences.getString("source_value", "");
        loadPlaylist(type, source);
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        return t;
    }

    private GradientDrawable background(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    private StateListDrawable focusBackground(int standard) {
        StateListDrawable d = new StateListDrawable();
        d.addState(new int[]{android.R.attr.state_focused}, background(ACCENT, 10, WHITE, 2));
        d.addState(new int[]{android.R.attr.state_pressed}, background(ACCENT, 10, WHITE, 1));
        d.addState(new int[]{}, background(standard, 10, Color.TRANSPARENT, 0));
        return d;
    }

    private TextView action(String title, Runnable callback) {
        TextView t = text(title, 15, WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(10), dp(16), dp(10));
        t.setBackground(focusBackground(PANEL_ALT));
        t.setFocusable(true);
        t.setClickable(true);
        t.setOnClickListener(v -> callback.run());
        return t;
    }

    private void buildLayout() {
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(BACKGROUND);
        page.setPadding(dp(18), dp(12), dp(18), dp(9));
        setContentView(page);

        header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        page.addView(header, new LinearLayout.LayoutParams(-1, dp(64)));

        TextView brand = text("DR", 31, ACCENT, true);
        header.addView(brand);
        TextView brand2 = text(" TV", 31, WHITE, true);
        header.addView(brand2);
        appSubtitle = text("   |   YOUR CHANNELS. YOUR SCREEN.", 12, MUTED, true);
        header.addView(appSubtitle, new LinearLayout.LayoutParams(0, -1, 1));
        TextView file = action("Open M3U file", this::openDocumentPicker);
        header.addView(file);
        spacer(header, 9);
        TextView url = action("+ Add M3U URL", this::promptForUrl);
        header.addView(url);
        spacer(header, 9);
        TextView demo = action("Demo", () -> loadPlaylist("demo", ""));
        header.addView(demo);
        spacer(header, 9);
        TextView refresh = action("↻ Refresh", this::refreshPlaylist);
        header.addView(refresh);

        browseRow = new LinearLayout(this);
        browseRow.setOrientation(LinearLayout.HORIZONTAL);
        page.addView(browseRow, new LinearLayout.LayoutParams(-1, 0, 1));

        groupPanel = panel();
        browseRow.addView(groupPanel, new LinearLayout.LayoutParams(dp(190), -1));
        groupPanel.addView(section("CATEGORIES", "Browse by group"));
        groupList = new ListView(this);
        groupList.setDividerHeight(dp(4));
        groupList.setDivider(null);
        groupList.setSelector(background(ACCENT, 9, WHITE, 2));
        groupList.setBackgroundColor(Color.TRANSPARENT);
        groupPanel.addView(groupList, new LinearLayout.LayoutParams(-1, 0, 1));
        categoryAdapter = new CategoryAdapter();
        groupList.setAdapter(categoryAdapter);
        groupList.setOnItemClickListener((p, v, position, id) -> {
            chosenGroup = groups.get(position);
            categoryAdapter.notifyDataSetChanged();
            updateList();
            channelList.requestFocus();
        });
        spacer(browseRow, 10);

        channelPanel = panel();
        browseRow.addView(channelPanel, new LinearLayout.LayoutParams(dp(295), -1));
        channelPanel.addView(section("CHANNELS", "Select to watch"));
        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(16);
        search.setTextColor(WHITE);
        search.setHintTextColor(MUTED);
        search.setHint("Search channels…");
        search.setPadding(dp(13), dp(8), dp(13), dp(8));
        search.setBackground(focusBackground(PANEL_ALT));
        search.setInputType(InputType.TYPE_CLASS_TEXT);
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(-1, dp(46));
        searchLp.setMargins(dp(6), dp(4), dp(6), dp(8));
        channelPanel.addView(search, searchLp);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { updateList(); }
            @Override public void afterTextChanged(Editable e) {}
        });
        channelList = new ListView(this);
        channelList.setDividerHeight(dp(3));
        channelList.setDivider(null);
        channelList.setSelector(background(ACCENT, 9, WHITE, 2));
        channelList.setBackgroundColor(Color.TRANSPARENT);
        channelPanel.addView(channelList, new LinearLayout.LayoutParams(-1, 0, 1));
        channelAdapter = new ChannelAdapter();
        channelList.setAdapter(channelAdapter);
        channelList.setOnItemClickListener((p, v, position, id) -> {
            Channel choice = shownChannels.get(position);
            if (selected != null && selected.key.equals(choice.key) && player.isPlaying()) {
                toggleFullScreen();
            } else {
                play(choice);
            }
        });
        spacer(browseRow, 10);

        playerPanel = panel();
        browseRow.addView(playerPanel, new LinearLayout.LayoutParams(0, -1, 1));
        TextView previewHeading = section("NOW PLAYING", "Select a channel to start");
        playerPanel.addView(previewHeading);
        FrameLayout videoFrame = new FrameLayout(this);
        videoFrame.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams videoLp = new LinearLayout.LayoutParams(-1, 0, 1);
        videoLp.setMargins(dp(7), 0, dp(7), 0);
        playerPanel.addView(videoFrame, videoLp);
        playerView = new PlayerView(this);
        playerView.setPlayer(player);
        playerView.setUseController(false);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        videoFrame.addView(playerView, new FrameLayout.LayoutParams(-1, -1));
        placeholder = text("SELECT A CHANNEL", 19, MUTED, true);
        placeholder.setGravity(Gravity.CENTER);
        placeholder.setBackgroundColor(Color.BLACK);
        videoFrame.addView(placeholder, new FrameLayout.LayoutParams(-1, -1));
        titleNow = text("No channel selected", 22, WHITE, true);
        titleNow.setPadding(dp(9), dp(9), dp(9), 0);
        playerPanel.addView(titleNow, new LinearLayout.LayoutParams(-1, dp(46)));
        status = text("Add an M3U playlist or try the included demo.", 13, MUTED, false);
        status.setPadding(dp(9), 0, dp(9), dp(7));
        playerPanel.addView(status, new LinearLayout.LayoutParams(-1, dp(31)));
        playerButtons = new LinearLayout(this);
        playerButtons.setPadding(dp(6), 0, dp(6), dp(4));
        playerPanel.addView(playerButtons, new LinearLayout.LayoutParams(-1, dp(51)));
        fullscreenButton = action("⛶ Full screen", this::toggleFullScreen);
        playerButtons.addView(fullscreenButton, new LinearLayout.LayoutParams(0, -1, 1));
        spacer(playerButtons, 7);
        favouriteButton = action("☆ Favourite", this::toggleFavourite);
        playerButtons.addView(favouriteButton, new LinearLayout.LayoutParams(0, -1, 1));
        spacer(playerButtons, 7);
        TextView stop = action("■ Stop", () -> {
            player.stop();
            status.setText("Playback stopped");
        });
        playerButtons.addView(stop, new LinearLayout.LayoutParams(0, -1, 1));

        footer = text("FIRE TV REMOTE  •  D-pad: navigate  •  OK: select  •  Play a channel again for full screen  •  Back: return", 12, MUTED, false);
        footer.setGravity(Gravity.CENTER_VERTICAL);
        page.addView(footer, new LinearLayout.LayoutParams(-1, dp(31)));
    }

    private LinearLayout panel() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(5), dp(5), dp(5), dp(5));
        panel.setBackground(background(PANEL, 13, Color.TRANSPARENT, 0));
        return panel;
    }

    private TextView section(String heading, String extra) {
        TextView t = text(heading + "  /  " + extra, 13, MUTED, true);
        t.setPadding(dp(11), dp(4), dp(6), dp(4));
        return t;
    }

    private void spacer(LinearLayout parent, int pixels) {
        parent.addView(new View(this), new LinearLayout.LayoutParams(dp(pixels), 1));
    }

    private void promptForUrl() {
        EditText field = new EditText(this);
        field.setSingleLine(false);
        field.setMinLines(1);
        field.setMaxLines(3);
        field.setTextSize(16);
        field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        field.setHint("https://example.com/playlist.m3u");
        if ("url".equals(preferences.getString("source_type", ""))) {
            field.setText(preferences.getString("source_value", ""));
            field.setSelectAllOnFocus(true);
        }
        LinearLayout container = new LinearLayout(this);
        container.setPadding(dp(20), dp(8), dp(20), 0);
        container.addView(field, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this)
            .setTitle("Add your M3U playlist")
            .setMessage("Paste a direct playlist URL from a source you're authorised to access.")
            .setView(container)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Load", (dialog, which) -> {
                String value = field.getText().toString().trim();
                if (!value.startsWith("https://") && !value.startsWith("http://")) {
                    toast("Playlist URL must begin with http:// or https://");
                    return;
                }
                loadPlaylist("url", value);
            }).show();
    }

    private void openDocumentPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_M3U);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_M3U && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (SecurityException ignored) { /* Some document providers do not support persistent grants. */ }
            loadPlaylist("file", uri.toString());
        }
    }

    private void refreshPlaylist() {
        loadPlaylist(preferences.getString("source_type", "demo"),
                     preferences.getString("source_value", ""));
    }

    private void loadPlaylist(String type, String value) {
        int generation = ++loadGeneration;
        status.setText("Loading playlist…");
        io.execute(() -> {
            try {
                List<Channel> loaded;
                if ("url".equals(type)) loaded = PlaylistLoader.remote(value);
                else if ("file".equals(type)) loaded = PlaylistLoader.document(getApplicationContext(), Uri.parse(value));
                else loaded = PlaylistLoader.demo(getApplicationContext());
                if (loaded.isEmpty()) throw new IllegalArgumentException("No playable HTTP(S) entries found in this M3U playlist");
                runOnUiThread(() -> {
                    if (isFinishing() || generation != loadGeneration) return;
                    preferences.edit().putString("source_type", type)
                        .putString("source_value", value).apply();
                    allChannels.clear();
                    allChannels.addAll(loaded);
                    chosenGroup = "All channels";
                    player.stop();
                    selected = null;
                    titleNow.setText("Choose a channel");
                    placeholder.setText("SELECT A CHANNEL");
                    placeholder.setVisibility(View.VISIBLE);
                    status.setText(loaded.size() + " items ready • Choose a channel");
                    appSubtitle.setText("   |   " + loaded.size() + " CHANNELS LOADED");
                    rebuildCategories();
                    updateList();
                    groupList.requestFocus();
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    if (isFinishing() || generation != loadGeneration) return;
                    String message = error.getMessage() == null ? "Unknown error" : error.getMessage();
                    status.setText("Playlist error: " + message);
                    toast("Couldn't load playlist: " + message);
                });
            }
        });
    }

    private void rebuildCategories() {
        groups.clear();
        groups.add("All channels");
        groups.add("★ Favourites");
        LinkedHashSet<String> unique = new LinkedHashSet<>();
        for (Channel c : allChannels) unique.add(c.group);
        groups.addAll(unique);
        categoryAdapter.notifyDataSetChanged();
    }

    private void updateList() {
        if (search == null || channelAdapter == null) return;
        String query = search.getText().toString().trim().toLowerCase(Locale.ROOT);
        shownChannels.clear();
        for (Channel c : allChannels) {
            boolean categoryMatch = "All channels".equals(chosenGroup)
                || ("★ Favourites".equals(chosenGroup) && favouriteKeys.contains(c.key))
                || c.group.equals(chosenGroup);
            boolean textMatch = query.isEmpty() || c.name.toLowerCase(Locale.ROOT).contains(query)
                || c.group.toLowerCase(Locale.ROOT).contains(query);
            if (categoryMatch && textMatch) shownChannels.add(c);
        }
        channelAdapter.notifyDataSetChanged();
    }

    private void play(Channel c) {
        selected = c;
        titleNow.setText(c.name);
        status.setText("Opening stream…");
        placeholder.setText("CONNECTING…");
        placeholder.setVisibility(View.VISIBLE);
        favouriteButton.setText(favouriteKeys.contains(c.key) ? "★ Favourited" : "☆ Favourite");
        MediaItem.Builder item = new MediaItem.Builder().setUri(c.streamUrl);
        String lower = c.streamUrl.toLowerCase(Locale.ROOT);
        if (lower.contains(".m3u8")) item.setMimeType(MimeTypes.APPLICATION_M3U8);
        else if (lower.contains(".mpd")) item.setMimeType(MimeTypes.APPLICATION_MPD);
        try {
            player.setMediaItem(item.build());
            player.prepare();
            player.play();
        } catch (RuntimeException error) {
            status.setText("Player error: " + error.getMessage());
        }
        channelAdapter.notifyDataSetChanged();
    }

    private void toggleFavourite() {
        if (selected == null) { toast("Choose a channel first"); return; }
        if (!favouriteKeys.add(selected.key)) favouriteKeys.remove(selected.key);
        preferences.edit().putStringSet("favourites", new HashSet<>(favouriteKeys)).apply();
        favouriteButton.setText(favouriteKeys.contains(selected.key) ? "★ Favourited" : "☆ Favourite");
        updateList();
    }

    private void toggleFullScreen() {
        if (selected == null) { toast("Choose a channel first"); return; }
        fullScreen = !fullScreen;
        header.setVisibility(fullScreen ? View.GONE : View.VISIBLE);
        groupPanel.setVisibility(fullScreen ? View.GONE : View.VISIBLE);
        channelPanel.setVisibility(fullScreen ? View.GONE : View.VISIBLE);
        footer.setVisibility(fullScreen ? View.GONE : View.VISIBLE);
        // The player panel remains visible and fills the remaining area.
        titleNow.setVisibility(fullScreen ? View.GONE : View.VISIBLE);
        status.setVisibility(fullScreen ? View.GONE : View.VISIBLE);
        playerButtons.setVisibility(fullScreen ? View.GONE : View.VISIBLE);
        if (!fullScreen) channelList.requestFocus();
    }

    private void changeChannel(int direction) {
        if (shownChannels.isEmpty()) return;
        int current = -1;
        if (selected != null) {
            for (int i = 0; i < shownChannels.size(); i++) {
                if (selected.key.equals(shownChannels.get(i).key)) { current = i; break; }
            }
        }
        int next = (current + direction + shownChannels.size()) % shownChannels.size();
        play(shownChannels.get(next));
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (fullScreen && event.getAction() == KeyEvent.ACTION_DOWN) {
            int key = event.getKeyCode();
            if (key == KeyEvent.KEYCODE_DPAD_UP || key == KeyEvent.KEYCODE_CHANNEL_UP) {
                changeChannel(-1); return true;
            }
            if (key == KeyEvent.KEYCODE_DPAD_DOWN || key == KeyEvent.KEYCODE_CHANNEL_DOWN) {
                changeChannel(1); return true;
            }
            if (key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_ENTER ||
                key == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
                if (player.isPlaying()) player.pause(); else player.play();
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override public void onBackPressed() {
        if (fullScreen) toggleFullScreen();
        else super.onBackPressed();
    }

    @Override protected void onStop() {
        super.onStop();
        if (player != null) player.pause();
    }

    @Override protected void onDestroy() {
        ++loadGeneration;
        io.shutdownNow();
        if (playerView != null) playerView.setPlayer(null);
        if (player != null) player.release();
        super.onDestroy();
    }

    @Override public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }

    private final class CategoryAdapter extends BaseAdapter {
        @Override public int getCount() { return groups.size(); }
        @Override public Object getItem(int position) { return groups.get(position); }
        @Override public long getItemId(int position) { return position; }
        @Override public View getView(int position, View existing, ViewGroup parent) {
            String name = groups.get(position);
            TextView row = text(name, 16, name.equals(chosenGroup) ? WHITE : MUTED,
                                name.equals(chosenGroup));
            row.setPadding(dp(12), dp(9), dp(5), dp(9));
            row.setMinHeight(dp(49));
            row.setBackground(background(name.equals(chosenGroup) ? PANEL_ALT : PANEL, 8,
                name.equals(chosenGroup) ? ACCENT : Color.TRANSPARENT,
                name.equals(chosenGroup) ? 2 : 0));
            return row;
        }
    }

    private final class ChannelAdapter extends BaseAdapter {
        @Override public int getCount() { return shownChannels.size(); }
        @Override public Object getItem(int position) { return shownChannels.get(position); }
        @Override public long getItemId(int position) { return position; }
        @Override public View getView(int position, View existing, ViewGroup parent) {
            Channel c = shownChannels.get(position);
            LinearLayout row = new LinearLayout(MainActivity.this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(11), dp(7), dp(9), dp(7));
            boolean playing = selected != null && selected.key.equals(c.key);
            row.setBackground(background(playing ? PANEL_ALT : PANEL, 8,
                playing ? ACCENT : Color.TRANSPARENT, playing ? 1 : 0));
            TextView number = text(String.format(Locale.ROOT, "%02d", position + 1), 15, ACCENT, true);
            row.addView(number, new LinearLayout.LayoutParams(dp(42), dp(48)));
            LinearLayout labels = new LinearLayout(MainActivity.this);
            labels.setOrientation(LinearLayout.VERTICAL);
            TextView name = text(c.name, 16, WHITE, playing);
            labels.addView(name, new LinearLayout.LayoutParams(-1, dp(26)));
            TextView info = text(c.group, 12, MUTED, false);
            labels.addView(info, new LinearLayout.LayoutParams(-1, dp(20)));
            row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
            if (favouriteKeys.contains(c.key)) {
                TextView heart = text("★", 21, ACCENT, true);
                row.addView(heart);
            }
            return row;
        }
    }
}
