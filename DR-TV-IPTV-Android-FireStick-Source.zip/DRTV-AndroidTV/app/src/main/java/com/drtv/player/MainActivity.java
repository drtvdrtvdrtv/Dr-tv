package com.drtv.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;
import java.io.IOException;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * DR TV Premium — Fire OS / Android TV. No provider or copyrighted media is bundled.
 * Three hero tiles and red/black branding reproduce the approved DR TV concept.
 * Real posters are loaded from the user's own authorised content provider.
 */
public final class MainActivity extends Activity {
    private static final int BG=Color.rgb(8,8,11);
    private static final int PANEL=Color.rgb(17,18,23);
    private static final int CARD=Color.rgb(24,25,31);
    private static final int ACCENT=Color.rgb(235,20,30);
    private static final int WHITE=Color.WHITE;
    private static final int MUTED=Color.rgb(168,169,176);
    private static final int PICK_M3U=41;
    private static final String PREFS="drtv_premium";
    private static final String HOME="Home", LIVE="Live TV", GUIDE="TV Guide", MOVIES="Movies",
        SERIES="Series", FAV="Favourites", CONTINUE="Continue Watching", DOWNLOADS="Downloads", SETTINGS="Settings";
    private final ExecutorService network=Executors.newSingleThreadExecutor();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final PosterLoader images=new PosterLoader();
    private final List<Channel> channels=new ArrayList<>();
    private final List<Channel> filteredChannels=new ArrayList<>();
    private final List<String> liveCategories=new ArrayList<>();
    private final List<XtreamClient.LibraryItem> movies=new ArrayList<>();
    private final List<XtreamClient.LibraryItem> series=new ArrayList<>();
    private final Set<String> favIds=new HashSet<>();
    private final Runnable saveTicker=new Runnable(){
        @Override public void run(){ savePlaybackPosition(); handler.postDelayed(this,10000); }
    };
    private ExoPlayer player;
    private PlayerView playerView;
    private CredentialVault vault;
    private WatchHistory history;
    private OfflineStore offline;
    private SharedPreferences prefs;
    private XtreamClient.Login login;
    private FrameLayout root, screenContent, livePreview, fullOverlay;
    private LinearLayout navColumn;
    private TextView playerStatus, playerHeading, liveFavButton;
    private String current=HOME, selectedCategory="All channels", selectedMediaCategory="";
    private String selectedMediaCategoryLabel="All";
    private Channel selectedChannel;
    private XtreamClient.LibraryItem selectedLibraryItem;
    private WatchHistory.Entry playingHistory;
    private long requestedSeekMs;
    private boolean fullScreen, demoMode, loadingLibrary, featuredFailed;
    private int generation=0;
    private int screenWidthDp, screenHeightDp;
    private int sidebarWidth;
    private ListView liveChannelList, liveCategoryList;
    private EditText liveSearch;
    private final List<XtreamClient.LibraryItem> shownLibrary=new ArrayList<>();
    private List<String> currentMediaCategories=new ArrayList<>();
    private final List<XtreamClient.LibraryCategory> currentCategoryModels=new ArrayList<>();
    private String currentLibraryQuery="";

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        CrashDiagnostics.install(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideBars();
        prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        vault=new CredentialVault(this);
        history=new WatchHistory(this);
        offline=new OfflineStore(this);
        favIds.addAll(prefs.getStringSet("favourites",Collections.emptySet()));
        float density=getResources().getDisplayMetrics().density;
        screenWidthDp=(int)(getResources().getDisplayMetrics().widthPixels/density);
        screenHeightDp=(int)(getResources().getDisplayMetrics().heightPixels/density);
        sidebarWidth=Math.max(154,Math.min(226,(int)(screenWidthDp*.195f)));
        player=new ExoPlayer.Builder(this).build();
        player.addListener(new Player.Listener(){
            @Override public void onPlayerError(PlaybackException e){
                final String errorCode=e.getErrorCodeName();
                setPlayerStatus("Playback error: "+errorCode);
                // Don't close the Activity when a provider has a missing/unsupported film.
                // Show an actionable error instead of leaving an unresponsive black screen.
                if(playingHistory!=null){
                    handler.post(()->{
                        if(isFinishing()||isDestroyed())return;
                        if(fullScreen)leaveFullScreen();
                        new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Unable to play this title")
                            .setMessage("This stream may be unavailable or use a format unsupported by your Fire Stick. " +
                                "Try another title. ("+errorCode+")")
                            .setPositiveButton("OK",null).show();
                        playingHistory=null;
                    });
                }else toast("Channel playback failed ("+errorCode+")");
            }
            @Override public void onPlaybackStateChanged(int state){
                if(state==Player.STATE_BUFFERING)setPlayerStatus("Buffering…");
                if(state==Player.STATE_READY){
                    setPlayerStatus("Now playing");
                    if(requestedSeekMs>0 && player.isCurrentMediaItemSeekable()){
                        player.seekTo(requestedSeekMs); requestedSeekMs=0;
                    }
                }
                if(state==Player.STATE_ENDED){
                    savePlaybackPosition(); setPlayerStatus("Playback ended");
                }
            }
        });
        playerView=new PlayerView(this);
        playerView.setPlayer(player);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerView.setUseController(false);
        handler.postDelayed(saveTicker,10000);
        showLogin(); // Always open on the login page, even if Remember me was selected.
    }

    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private void hideBars(){getWindow().getDecorView().setSystemUiVisibility(
        View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);}
    private GradientDrawable shape(int color,int radius,int stroke,int sw){
        GradientDrawable d=new GradientDrawable(); d.setColor(color);d.setCornerRadius(dp(radius));
        if(sw>0)d.setStroke(dp(sw),stroke);return d;
    }
    private GradientDrawable gradient(int a,int b,int radius){
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});
        d.setCornerRadius(dp(radius));return d;
    }
    private StateListDrawable focused(int normal,boolean selected){
        StateListDrawable s=new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused},shape(ACCENT,9,WHITE,2));
        s.addState(new int[]{android.R.attr.state_pressed},shape(ACCENT,9,WHITE,1));
        s.addState(new int[]{},shape(selected?ACCENT:normal,9,selected?ACCENT:Color.TRANSPARENT,selected?1:0));
        return s;
    }
    private TextView label(String text,int size,int color,boolean bold){
        TextView v=new TextView(this);v.setText(text);v.setTextSize(size);v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL);v.setIncludeFontPadding(true);
        if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        v.setEllipsize(TextUtils.TruncateAt.END);v.setMaxLines(2);return v;
    }
    private TextView clickable(String text,Runnable onClick){
        TextView v=label(text,15,WHITE,true);v.setGravity(Gravity.CENTER);
        v.setPadding(dp(16),dp(9),dp(16),dp(9));v.setBackground(focused(CARD,false));
        v.setFocusable(true);v.setClickable(true);v.setOnClickListener(w->onClick.run());return v;
    }
    private LinearLayout column(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout row(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);return v;}
    private LinearLayout.LayoutParams space(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private void gap(LinearLayout parent,int width){parent.addView(new View(this),space(width,1));}
    private void verticalGap(LinearLayout parent,int height){parent.addView(new View(this),space(1,height));}
    private ScrollView scroll(LinearLayout content){
        ScrollView s=new ScrollView(this);s.setFillViewport(false);s.setClipToPadding(false);
        s.addView(content);return s;
    }
    private ImageView image(int res){ImageView v=new ImageView(this);v.setImageResource(res);v.setScaleType(ImageView.ScaleType.CENTER_CROP);return v;}
    private TextView heading(String text,int size){
        TextView v=label(text,size,WHITE,true);v.setPadding(0,dp(7),0,dp(10));return v;
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private void setPlayerStatus(String msg){if(playerStatus!=null) playerStatus.setText(msg);}

    private EditText field(String hint,boolean password){
        EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);
        e.setTextSize(17);e.setTextColor(WHITE);e.setHintTextColor(MUTED);
        e.setPadding(dp(15),dp(8),dp(15),dp(8));
        e.setBackground(focused(CARD,false));
        e.setInputType(password? InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD:
            InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_NORMAL);
        return e;
    }

    /** A dedicated first-launch and each-launch login screen. No hard-coded credentials. */
    private void showLogin(){
        fullScreen=false; current=HOME;
        player.stop();playingHistory=null; selectedChannel=null; selectedLibraryItem=null;
        FrameLayout backdrop=new FrameLayout(this);backdrop.setBackgroundColor(BG);
        ImageView art=image(R.drawable.header_art);
        FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(-1,dp(Math.max(125,screenHeightDp/3)),Gravity.TOP);
        backdrop.addView(art,ap);
        LinearLayout layout=column();layout.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams body=new FrameLayout.LayoutParams(-1,-1);
        body.setMargins(dp(16),dp(8),dp(16),dp(8));ScrollView loginScroll=new ScrollView(this);loginScroll.setFillViewport(true);
        loginScroll.addView(layout);backdrop.addView(loginScroll,body);
        ImageView logo=image(R.drawable.brand_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        layout.addView(logo,space(226,95));
        LinearLayout card=column();card.setPadding(dp(30),dp(12),dp(30),dp(14));
        card.setBackground(shape(PANEL,16,ACCENT,1));
        LinearLayout.LayoutParams cp=space(Math.min(555,screenWidthDp-80),-2);
        cp.topMargin=dp(0);layout.addView(card,cp);
        TextView title=label("WELCOME TO DR TV",25,WHITE,true);title.setGravity(Gravity.CENTER);
        card.addView(title,space(-1,36));
        TextView hint=label("Sign in with your IPTV provider",14,MUTED,false);hint.setGravity(Gravity.CENTER);
        card.addView(hint,space(-1,26));
        EditText dns=field("DNS / server — https://example.com:8080",false);
        EditText username=field("Username",false);
        EditText password=field("Password",true);
        TextView serverLabel=label("DNS / SERVER URL",12,WHITE,true);
        card.addView(serverLabel,space(-1,21));card.addView(dns,space(-1,46));
        TextView userLabel=label("USERNAME",12,WHITE,true);
        card.addView(userLabel,space(-1,22));card.addView(username,space(-1,46));
        TextView passLabel=label("PASSWORD",12,WHITE,true);
        card.addView(passLabel,space(-1,22));card.addView(password,space(-1,46));
        CheckBox remember=new CheckBox(this);remember.setText("Remember me on this Fire Stick");
        remember.setTextColor(WHITE);remember.setTextSize(14);
        remember.setButtonTintList(ColorStateList.valueOf(ACCENT));
        card.addView(remember,space(-1,41));
        XtreamClient.Login saved=vault.read();
        if(saved!=null){
            dns.setText(saved.server);username.setText(saved.username);password.setText(saved.password);
            remember.setChecked(true);
        }
        TextView status=label("",13,MUTED,false);
        status.setGravity(Gravity.CENTER);card.addView(status,space(-1,28));
        LinearLayout buttons=row();buttons.setGravity(Gravity.CENTER);card.addView(buttons,space(-1,49));
        TextView connect=clickable("CONNECT  ▶",()->{
            if(status.getText().toString().equals("Connecting…"))return;
            XtreamClient.Login candidate;
            try {candidate=XtreamClient.credentials(dns.getText().toString(),
                username.getText().toString(),password.getText().toString());}
            catch(IOException error){status.setText(error.getMessage());return;}
            status.setText("Connecting…");
            final boolean save=remember.isChecked();
            final int token=++generation;
            network.execute(()->{
                try{
                    List<Channel> result=XtreamClient.loadLiveChannels(candidate);
                    runOnUiThread(()->{
                        if(token!=generation||isFinishing())return;
                        if(save){
                            try{vault.save(candidate.server,candidate.username,candidate.password);}
                            catch(Exception ignored){toast("Couldn't save login securely on this device");}
                        }else vault.clear();
                        login=candidate;demoMode=false;featuredFailed=false;channels.clear();channels.addAll(result);
                        movies.clear();series.clear(); selectedCategory="All channels";
                        buildShell(); showSection(HOME); loadFeatured();
                    });
                }catch(Exception error){
                    runOnUiThread(()->{
                        if(token!=generation||isFinishing())return;
                        status.setText(error.getMessage()==null?"Couldn't connect":error.getMessage());
                    });
                }
            });
        });
        buttons.addView(connect,new LinearLayout.LayoutParams(0,dp(47),1));gap(buttons,8);
        TextView demo=clickable("TRY DEMO",()->{
            final int token=++generation;
            status.setText("Loading demo…");
            network.execute(()->{
                try{
                    List<Channel> result=PlaylistLoader.demo(getApplicationContext());
                    runOnUiThread(()->{
                        if(token!=generation||isFinishing())return;
                        demoMode=true;login=null;channels.clear();channels.addAll(result);
                        movies.clear();series.clear();selectedCategory="All channels";
                        buildShell();showSection(HOME);
                    });
                }catch(Exception e){runOnUiThread(()->status.setText("Demo unavailable"));}
            });
        });
        buttons.addView(demo,new LinearLayout.LayoutParams(0,dp(47),.65f));
        TextView note=label("Only use streams you are authorised to access. HTTPS protects your login in transit; HTTP does not.",12,MUTED,false);
        note.setGravity(Gravity.CENTER);note.setMaxLines(3);
        card.addView(note,space(-1,37));
        setContentView(backdrop);
        connect.requestFocus();
    }

    private void buildShell(){
        root=new FrameLayout(this);root.setBackgroundColor(BG);
        LinearLayout shell=column();root.addView(shell,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout top=row();top.setGravity(Gravity.CENTER_VERTICAL);
        int headerHeight=Math.max(74,Math.min(104,(int)(screenHeightDp*.17f)));
        shell.addView(top,space(-1,headerHeight));
        ImageView logo=image(R.drawable.brand_logo);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        top.addView(logo,space(sidebarWidth,headerHeight));
        FrameLayout bar=new FrameLayout(this);top.addView(bar,new LinearLayout.LayoutParams(0,-1,1));
        ImageView skull=image(R.drawable.header_art);
        skull.setAlpha(.6f);bar.addView(skull,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout toolbar=row();toolbar.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(8),0,dp(18),0);
        bar.addView(toolbar,new FrameLayout.LayoutParams(-1,-1));
        TextView search=clickable("⌕",()->showSection(current.equals(MOVIES)||current.equals(SERIES)?current:LIVE));
        search.setTextSize(23);toolbar.addView(search,space(50,47));gap(toolbar,10);
        TextView settings=clickable("⚙",()->showSection(SETTINGS));
        settings.setTextSize(23);toolbar.addView(settings,space(50,47));gap(toolbar,17);
        LinearLayout clocks=column();clocks.setGravity(Gravity.CENTER);
        TextClock clock=new TextClock(this);clock.setFormat12Hour("hh:mm");clock.setFormat24Hour("HH:mm");
        clock.setTextColor(WHITE);clock.setTextSize(24);clock.setGravity(Gravity.RIGHT);
        TextClock date=new TextClock(this);date.setFormat12Hour("EEE d MMM");date.setFormat24Hour("EEE d MMM");
        date.setTextColor(MUTED);date.setTextSize(12);date.setGravity(Gravity.RIGHT);
        clocks.addView(clock);clocks.addView(date);toolbar.addView(clocks,space(112,66));
        LinearLayout body=row();shell.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        navColumn=column();navColumn.setPadding(dp(9),dp(6),dp(9),dp(6));
        navColumn.setBackground(gradient(Color.rgb(10,10,12),Color.rgb(16,10,12),0));
        body.addView(navColumn,space(sidebarWidth,-1));
        screenContent=new FrameLayout(this);
        screenContent.setPadding(dp(10),0,dp(12),dp(8));
        body.addView(screenContent,new LinearLayout.LayoutParams(0,-1,1));
        setContentView(root);
    }

    private void buildNavigation(){
        navColumn.removeAllViews();
        String[] destinations={HOME,LIVE,GUIDE,MOVIES,SERIES,FAV,CONTINUE,DOWNLOADS,SETTINGS};
        String[] symbols={"⌂","▣","▦","▰","▤","☆","◷","⇩","⚙"};
        for(int i=0;i<destinations.length;i++){
            String name=destinations[i];
            TextView item=label(symbols[i]+"   "+name,Math.max(12,Math.min(16,screenHeightDp/39)),WHITE,name.equals(current));
            item.setSingleLine(true);
            item.setPadding(dp(12),0,dp(4),0);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setBackground(focused(Color.TRANSPARENT,name.equals(current)));
            item.setFocusable(true);item.setClickable(true);
            item.setOnClickListener(v->showSection(name));
            int navH=Math.max(34,Math.min(50,(screenHeightDp - Math.max(74,Math.min(104,(int)(screenHeightDp*.17f))) - 30)/9));
            LinearLayout.LayoutParams lp=space(-1,navH);
            lp.bottomMargin=dp(2);navColumn.addView(item,lp);
            if(name.equals(current))item.requestFocus();
        }
    }

    private void showSection(String name){
        if(root==null)return;
        if(fullScreen)leaveFullScreen();
        if(!name.equals(LIVE) && player.isPlaying()) {
            savePlaybackPosition();player.pause();
        }
        current=name;buildNavigation();screenContent.removeAllViews();livePreview=null;
        switch(name){
            case HOME:renderHome();break;
            case LIVE:renderLive();break;
            case GUIDE:renderGuide();break;
            case MOVIES:renderLibrary(false);break;
            case SERIES:renderLibrary(true);break;
            case FAV:renderFavourites();break;
            case CONTINUE:renderHistory();break;
            case DOWNLOADS:renderDownloads();break;
            default:renderSettings();
        }
    }

    private void renderHome(){
        LinearLayout content=column();content.setPadding(dp(4),dp(4),dp(4),dp(20));
        screenContent.addView(scroll(content),new FrameLayout.LayoutParams(-1,-1));
        LinearLayout hero=row();
        int heroH=Math.max(118,Math.min(203,(int)(screenHeightDp*.32f)));
        content.addView(hero,space(-1,heroH));
        addHero(hero,R.drawable.hero_live,()->showSection(LIVE));gap(hero,8);
        addHero(hero,R.drawable.hero_movies,()->showSection(MOVIES));gap(hero,8);
        addHero(hero,R.drawable.hero_series,()->showSection(SERIES));
        verticalGap(content,8);
        headerWithAction(content,"Continue Watching",()->showSection(CONTINUE));
        List<WatchHistory.Entry> recent=history.get();
        if(recent.isEmpty()){
            TextView empty=label("Start a movie or episode to see it here.",14,MUTED,false);
            content.addView(empty,space(-1,55));
        }else{
            HorizontalScrollView list=new HorizontalScrollView(this);list.setHorizontalScrollBarEnabled(false);
            LinearLayout thumbnails=row();thumbnails.setPadding(0,0,0,dp(6));list.addView(thumbnails);
            for(int i=0;i<Math.min(10,recent.size());i++)addHistoryTile(thumbnails,recent.get(i),true);
            content.addView(list,space(-1,Math.max(124,Math.min(184,(int)(screenHeightDp*.29f)))));
        }
        headerWithAction(content,"Popular Movies",()->showSection(MOVIES));
        HorizontalScrollView strip=new HorizontalScrollView(this);strip.setHorizontalScrollBarEnabled(false);
        LinearLayout posters=row();posters.setPadding(0,0,0,dp(7));strip.addView(posters);
        if(movies.isEmpty()){
            TextView hint=label(demoMode?"Sign in to load your movie library":
                (featuredFailed?"Your provider has no movie library, or it is unavailable.":"Loading movies from your provider…"),14,MUTED,false);
            posters.addView(hint,space(-1,65));
        }else {
            for(int i=0;i<Math.min(14,movies.size());i++){
                XtreamClient.LibraryItem item=movies.get(i);
                posters.addView(posterTile(item,116,160,()->openLibraryItem(item)),space(116,160));
                gap(posters,9);
            }
        }
        content.addView(strip,space(-1,Math.max(180,Math.min(220,(int)(screenHeightDp*.34f)))));
    }

    private void addHero(LinearLayout row,int drawable,Runnable onClick){
        FrameLayout frame=new FrameLayout(this);frame.setFocusable(true);frame.setClickable(true);
        frame.setBackground(focused(PANEL,false));
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(-1,-1);
        p.setMargins(dp(2),dp(2),dp(2),dp(2));
        frame.addView(image(drawable),p);frame.setOnClickListener(v->onClick.run());
        row.addView(frame,new LinearLayout.LayoutParams(0,-1,1));
    }
    private void headerWithAction(LinearLayout parent,String title,Runnable action){
        LinearLayout r=row();r.setGravity(Gravity.CENTER_VERTICAL);
        parent.addView(r,space(-1,46));
        TextView h=heading(title,22);r.addView(h,new LinearLayout.LayoutParams(0,-1,1));
        TextView see=clickable("View All ›",action);see.setTextSize(13);
        r.addView(see,space(100,36));
    }
    private void addHistoryTile(LinearLayout parent,WatchHistory.Entry entry,boolean landscape){
        int w=landscape?232:146,h=landscape?148:178;
        FrameLayout card=new FrameLayout(this);card.setFocusable(true);
        card.setBackground(focused(CARD,false));
        ImageView poster=image(R.drawable.hero_movies);
        FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-1,-1);
        ip.setMargins(dp(2),dp(2),dp(2),dp(2));card.addView(poster,ip);
        images.load(poster,entry.poster,R.drawable.hero_movies);
        LinearLayout detail=column();detail.setGravity(Gravity.BOTTOM);
        detail.setPadding(dp(8),0,dp(8),dp(7));
        detail.setBackground(gradient(Color.TRANSPARENT,Color.rgb(10,10,13),0));
        card.addView(detail,new FrameLayout.LayoutParams(-1,-1));
        TextView label=label(entry.title,14,WHITE,true);detail.addView(label,space(-1,35));
        View progress=new View(this);progress.setBackgroundColor(ACCENT);
        long duration=Math.max(1,entry.durationMs);
        FrameLayout bar=new FrameLayout(this);bar.setBackgroundColor(Color.DKGRAY);
        detail.addView(bar,space(-1,4));
        FrameLayout.LayoutParams fill=new FrameLayout.LayoutParams(-1,-1);
        bar.addView(progress,fill);
        bar.post(()->{ViewGroup.LayoutParams lp=progress.getLayoutParams();
            lp.width=(int)(bar.getWidth()*Math.max(.02,Math.min(.98,entry.positionMs/(double)duration)));
            progress.setLayoutParams(lp);});
        card.setOnClickListener(v->resumeHistory(entry));
        LinearLayout.LayoutParams outer=space(w,h);outer.rightMargin=dp(8);parent.addView(card,outer);
    }

    private FrameLayout posterTile(XtreamClient.LibraryItem item,int width,int height,Runnable onClick){
        FrameLayout tile=new FrameLayout(this);tile.setBackground(focused(PANEL,false));
        tile.setFocusable(true);tile.setClickable(true);tile.setContentDescription(item.title);
        ImageView art=image(R.drawable.hero_movies);
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(-1,-1);
        p.setMargins(dp(2),dp(2),dp(2),dp(2));tile.addView(art,p);
        images.load(art,item.poster,R.drawable.hero_movies);
        TextView title=label(item.title,13,WHITE,true);
        title.setPadding(dp(5),dp(2),dp(5),dp(2));title.setBackgroundColor(0xcc09090c);
        tile.addView(title,new FrameLayout.LayoutParams(-1,dp(36),Gravity.BOTTOM));
        tile.setOnClickListener(v->onClick.run());
        return tile;
    }

    private void renderLive(){
        LinearLayout main=row();screenContent.addView(main,new FrameLayout.LayoutParams(-1,-1));
        int available=Math.max(550,screenWidthDp-sidebarWidth-40);
        int cW=Math.max(140,(int)(available*.245));
        int lW=Math.max(210,(int)(available*.34));
        LinearLayout categories=panel("CATEGORIES");main.addView(categories,space(cW,-1));gap(main,8);
        buildLiveCategories();
        liveCategoryList=new ListView(this);styleList(liveCategoryList);
        liveCategoryList.setAdapter(new BaseAdapter(){
            @Override public int getCount(){return liveCategories.size();}
            @Override public Object getItem(int p){return liveCategories.get(p);}
            @Override public long getItemId(int p){return p;}
            @Override public View getView(int p,View old,ViewGroup parent){
                String name=liveCategories.get(p);return listRow(name, name.equals(selectedCategory));
            }
        });
        categories.addView(liveCategoryList,new LinearLayout.LayoutParams(-1,0,1));
        liveCategoryList.setOnItemClickListener((par,v,index,id)->{
            selectedCategory=liveCategories.get(index);refilterChannels();
            ((BaseAdapter)liveCategoryList.getAdapter()).notifyDataSetChanged();
            liveChannelList.requestFocus();
        });
        LinearLayout listing=panel("CHANNELS");main.addView(listing,space(lW,-1));gap(main,8);
        liveSearch=field("Search channels…",false);liveSearch.setTextSize(14);
        listing.addView(liveSearch,space(-1,42));
        liveChannelList=new ListView(this);styleList(liveChannelList);
        listing.addView(liveChannelList,new LinearLayout.LayoutParams(-1,0,1));
        liveChannelList.setAdapter(new BaseAdapter(){
            @Override public int getCount(){return filteredChannels.size();}
            @Override public Object getItem(int p){return filteredChannels.get(p);}
            @Override public long getItemId(int p){return p;}
            @Override public View getView(int p,View old,ViewGroup parent){
                Channel c=filteredChannels.get(p);
                return listRow(String.format(Locale.ROOT,"%03d   %s%s",p+1,c.name,
                    favIds.contains(liveId(c))?"  ★":""),
                    selectedChannel!=null && selectedChannel.key.equals(c.key));
            }
        });
        liveChannelList.setOnItemClickListener((par,v,index,id)->{
            Channel choice=filteredChannels.get(index);
            if(selectedChannel!=null&&selectedChannel.key.equals(choice.key)&&player.isPlaying())enterFullScreen();
            else playLive(choice,false);
        });
        liveSearch.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int st,int before,int count){refilterChannels();}
            @Override public void afterTextChanged(Editable e){}
        });
        LinearLayout preview=panel("NOW PLAYING");main.addView(preview,new LinearLayout.LayoutParams(0,-1,1));
        livePreview=new FrameLayout(this);livePreview.setBackgroundColor(Color.BLACK);
        preview.addView(livePreview,new LinearLayout.LayoutParams(-1,0,1));
        attachPlayer(livePreview);
        playerHeading=label(selectedChannel==null?"Choose a channel":selectedChannel.name,18,WHITE,true);
        playerHeading.setPadding(dp(8),dp(8),dp(8),dp(2));preview.addView(playerHeading,space(-1,44));
        playerStatus=label("Select a channel to start",13,MUTED,false);
        preview.addView(playerStatus,space(-1,29));
        LinearLayout tools=row();preview.addView(tools,space(-1,51));
        tools.addView(clickable("⛶ Full screen",this::enterFullScreen),new LinearLayout.LayoutParams(0,-1,1));gap(tools,5);
        liveFavButton=clickable("☆ Favourite",this::toggleLiveFavourite);
        tools.addView(liveFavButton,new LinearLayout.LayoutParams(0,-1,1));gap(tools,5);
        tools.addView(clickable("Guide",()->{current=GUIDE;showSection(GUIDE);}),new LinearLayout.LayoutParams(0,-1,1));
        refilterChannels();
    }
    private void buildLiveCategories(){
        liveCategories.clear();liveCategories.add("All channels");liveCategories.add("★ Favourites");
        LinkedHashSet<String> values=new LinkedHashSet<>();
        for(Channel c:channels)values.add(c.group);
        liveCategories.addAll(values);
    }
    private void refilterChannels(){
        filteredChannels.clear();
        String query=liveSearch==null?"":liveSearch.getText().toString().toLowerCase(Locale.ROOT).trim();
        for(Channel c:channels){
            boolean belongs=selectedCategory.equals("All channels") ||
                (selectedCategory.equals("★ Favourites")&&favIds.contains(liveId(c))) ||
                selectedCategory.equals(c.group);
            if(belongs && (query.isEmpty()||c.name.toLowerCase(Locale.ROOT).contains(query)))filteredChannels.add(c);
        }
        if(liveChannelList!=null && liveChannelList.getAdapter() instanceof BaseAdapter)
            ((BaseAdapter)liveChannelList.getAdapter()).notifyDataSetChanged();
    }
    private LinearLayout panel(String title){
        LinearLayout out=column();out.setBackground(shape(PANEL,11,Color.rgb(44,25,29),1));
        out.setPadding(dp(7),dp(6),dp(7),dp(5));
        TextView h=label(title,13,MUTED,true);h.setPadding(dp(6),0,dp(6),0);
        out.addView(h,space(-1,37));return out;
    }
    private void styleList(ListView list){
        list.setBackgroundColor(Color.TRANSPARENT);list.setCacheColorHint(Color.TRANSPARENT);
        list.setDivider(null);list.setDividerHeight(dp(3));
        list.setSelector(shape(ACCENT,8,WHITE,2));
        list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
    }
    private TextView listRow(String text,boolean selected){
        TextView row=label(text,14,selected?WHITE:MUTED,selected);
        row.setPadding(dp(10),dp(9),dp(6),dp(9));row.setMinHeight(dp(47));
        row.setSingleLine(true);row.setBackground(focused(CARD,selected));return row;
    }
    private void attachPlayer(FrameLayout target){
        ViewGroup parent=(ViewGroup)playerView.getParent();
        if(parent!=null)parent.removeView(playerView);
        target.addView(playerView,new FrameLayout.LayoutParams(-1,-1));
        playerView.setKeepScreenOn(true);
    }
    private void playLive(Channel c,boolean launchFull){
        savePlaybackPosition();selectedChannel=c;selectedLibraryItem=null;playingHistory=null;
        requestedSeekMs=0;
        MediaItem.Builder media=new MediaItem.Builder().setUri(c.streamUrl);
        if(c.streamUrl.toLowerCase(Locale.ROOT).contains(".m3u8"))media.setMimeType(MimeTypes.APPLICATION_M3U8);
        try{player.setMediaItem(media.build());player.prepare();player.play();}
        catch(Exception e){toast("This channel could not be opened");}
        if(playerHeading!=null)playerHeading.setText(c.name);
        if(liveFavButton!=null)liveFavButton.setText(favIds.contains(liveId(c))?"★ Favourited":"☆ Favourite");
        if(liveChannelList!=null && liveChannelList.getAdapter() instanceof BaseAdapter)
            ((BaseAdapter)liveChannelList.getAdapter()).notifyDataSetChanged();
        if(launchFull)enterFullScreen();
    }
    private String liveId(Channel c){
        String path=Uri.parse(c.streamUrl).getLastPathSegment();
        return "live:"+(path==null?c.key:path.replaceAll("\\.(ts|m3u8)$",""));
    }
    private void toggleLiveFavourite(){
        if(selectedChannel==null){toast("Select a channel first");return;}
        changeFavourite(liveId(selectedChannel));
        if(liveFavButton!=null)liveFavButton.setText(favIds.contains(liveId(selectedChannel))?"★ Favourited":"☆ Favourite");
        if(liveChannelList!=null && liveChannelList.getAdapter() instanceof BaseAdapter)
            ((BaseAdapter)liveChannelList.getAdapter()).notifyDataSetChanged();
    }
    private void changeFavourite(String id){
        if(!favIds.add(id))favIds.remove(id);
        prefs.edit().putStringSet("favourites",new HashSet<>(favIds)).apply();
    }

    private void renderGuide(){
        LinearLayout content=row();screenContent.addView(content,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout left=panel("LIVE CHANNELS");content.addView(left,new LinearLayout.LayoutParams(0,-1,.44f));gap(content,10);
        ListView choices=new ListView(this);styleList(choices);
        left.addView(choices,new LinearLayout.LayoutParams(-1,0,1));
        choices.setAdapter(new BaseAdapter(){
            @Override public int getCount(){return channels.size();}
            @Override public Object getItem(int index){return channels.get(index);}
            @Override public long getItemId(int index){return index;}
            @Override public View getView(int index,View old,ViewGroup parent){return listRow(channels.get(index).name,false);}
        });
        LinearLayout right=panel("TV GUIDE / NEXT PROGRAMMES");content.addView(right,new LinearLayout.LayoutParams(0,-1,.56f));
        TextView title=heading("Select a channel to see its schedule",18);right.addView(title,space(-1,47));
        TextView guideNote=label("Guide availability depends on your provider.",13,MUTED,false);
        right.addView(guideNote,space(-1,31));
        ScrollView scroll=new ScrollView(this);LinearLayout entries=column();scroll.addView(entries);
        right.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        choices.setOnItemClickListener((parent,v,index,id)->{
            Channel c=channels.get(index);selectedChannel=c;title.setText(c.name);
            entries.removeAllViews();entries.addView(listRow("Loading programme guide…",false));
            if(login==null){entries.removeAllViews();entries.addView(listRow("Demo mode: no provider guide available",false));return;}
            String filename=Uri.parse(c.streamUrl).getLastPathSegment();
            if(filename==null||!filename.matches("[0-9]+\\.(ts|m3u8)")){
                entries.removeAllViews();entries.addView(listRow("No guide ID for this channel",false));return;
            }
            String streamId=filename.substring(0,filename.indexOf('.'));
            int token=++generation;
            network.execute(()->{
                try{
                    List<String> guide=XtreamClient.shortGuide(login,streamId);
                    runOnUiThread(()->{
                        if(token!=generation||!GUIDE.equals(current))return;
                        entries.removeAllViews();
                        if(guide.isEmpty())entries.addView(listRow("No programme data supplied",false));
                        else for(String text:guide){
                            TextView e=label(text,15,WHITE,false);e.setPadding(dp(12),dp(9),dp(10),dp(9));
                            e.setBackground(shape(CARD,8,Color.TRANSPARENT,0));
                            LinearLayout.LayoutParams lp=space(-1,59);lp.bottomMargin=dp(6);entries.addView(e,lp);
                        }
                    });
                }catch(Exception e){runOnUiThread(()->{
                    if(token==generation && GUIDE.equals(current)){
                        entries.removeAllViews();entries.addView(listRow("Programme guide unavailable",false));
                    }
                });}
            });
        });

    }

    private void loadFeatured(){
        if(login==null||loadingLibrary)return;
        loadingLibrary=true;XtreamClient.Login currentLogin=login;
        network.execute(()->{
            try{
                List<XtreamClient.LibraryItem> list=XtreamClient.loadLibrary(currentLogin,false,"");
                runOnUiThread(()->{
                    if(login!=currentLogin)return;
                    loadingLibrary=false;featuredFailed=false;movies.clear();movies.addAll(list);
                    if(current.equals(HOME))renderFreshSection();
                });
            }catch(Exception e){runOnUiThread(()->{loadingLibrary=false;featuredFailed=true;
                if(HOME.equals(current))renderFreshSection();});}
        });
    }
    private void renderFreshSection(){
        if(root==null)return;
        String target=current;
        screenContent.removeAllViews();
        if(target.equals(HOME))renderHome();
        else if(target.equals(MOVIES))renderLibrary(false);
        else if(target.equals(SERIES))renderLibrary(true);
    }
    private void renderLibrary(boolean isSeries){
        screenContent.removeAllViews();
        if(login==null){emptyPage("Sign in to load "+(isSeries?"series":"movies")+".");return;}
        LinearLayout whole=column();screenContent.addView(whole,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout top=row();top.setGravity(Gravity.CENTER_VERTICAL);whole.addView(top,space(-1,50));
        TextView title=heading(isSeries?"SERIES":"MOVIES",23);
        top.addView(title,new LinearLayout.LayoutParams(0,-1,1));
        TextView searchButton=clickable("⌕ Search",()->promptLibrarySearch(isSeries));
        top.addView(searchButton,space(120,39));
        LinearLayout body=row();whole.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout cats=panel("CATEGORIES");
        body.addView(cats,space(Math.max(150,(int)((screenWidthDp-sidebarWidth)*.22)),-1));gap(body,9);
        ListView categories=new ListView(this);styleList(categories);
        cats.addView(categories,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout items=panel("BROWSE LIBRARY");body.addView(items,new LinearLayout.LayoutParams(0,-1,1));
        TextView feedback=label("Loading provider library…",13,MUTED,false);items.addView(feedback,space(-1,30));
        GridView grid=new GridView(this);grid.setNumColumns(4);grid.setHorizontalSpacing(dp(10));
        grid.setVerticalSpacing(dp(12));grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setClipToPadding(false);grid.setFocusable(true);grid.setPadding(dp(5),dp(4),dp(5),dp(6));
        items.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        final boolean seriesFlag=isSeries;
        // Let GridView, not each poster child, own D-pad focus and OK clicks.
        // Recycling tiles avoids creating hundreds of heavyweight image views while browsing.
        BaseAdapter adapter=new BaseAdapter(){
            @Override public int getCount(){return shownLibrary.size();}
            @Override public Object getItem(int p){return shownLibrary.get(p);}
            @Override public long getItemId(int p){return p;}
            @Override public View getView(int pos,View convert,ViewGroup parent){
                XtreamClient.LibraryItem item=shownLibrary.get(pos);
                FrameLayout tile;
                ImageView art;
                TextView text;
                if(convert instanceof FrameLayout && ((FrameLayout)convert).getChildCount()==2){
                    tile=(FrameLayout)convert;
                    art=(ImageView)tile.getChildAt(0);
                    text=(TextView)tile.getChildAt(1);
                }else{
                    tile=new FrameLayout(MainActivity.this);
                    tile.setBackground(shape(PANEL,9,Color.TRANSPARENT,0));
                    tile.setLayoutParams(new android.widget.AbsListView.LayoutParams(-1,dp(198)));
                    art=image(R.drawable.hero_movies);
                    FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(-1,-1);
                    ap.setMargins(dp(2),dp(2),dp(2),dp(2));tile.addView(art,ap);
                    text=label("",13,WHITE,true);
                    text.setPadding(dp(5),dp(2),dp(5),dp(2));
                    text.setBackgroundColor(0xcc09090c);
                    tile.addView(text,new FrameLayout.LayoutParams(-1,dp(36),Gravity.BOTTOM));
                }
                tile.setFocusable(false);
                tile.setClickable(false);
                tile.setOnClickListener(null);
                tile.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
                tile.setContentDescription(item.title);
                text.setText(item.title);
                // Avoid re-downloading a poster for the same recycled view.
                if(!java.util.Objects.equals(item.poster,art.getTag()))
                    images.load(art,item.poster,R.drawable.hero_movies);
                return tile;
            }
        };
        grid.setSelector(shape(Color.TRANSPARENT,8,ACCENT,2));
        grid.setDrawSelectorOnTop(true);
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((p,v,pos,id)->{
            if(pos>=0 && pos<shownLibrary.size())openLibraryItem(shownLibrary.get(pos));
        });
        categories.setAdapter(new BaseAdapter(){
            @Override public int getCount(){return currentCategoryModels.size();}
            @Override public Object getItem(int p){return currentCategoryModels.get(p);}
            @Override public long getItemId(int p){return p;}
            @Override public View getView(int p,View old,ViewGroup parent){
                XtreamClient.LibraryCategory c=currentCategoryModels.get(p);
                return listRow(c.name,c.id.equals(selectedMediaCategory));
            }
        });
        categories.setOnItemClickListener((p,v,index,id)->{
            XtreamClient.LibraryCategory c=currentCategoryModels.get(index);
            selectedMediaCategory=c.id;selectedMediaCategoryLabel=c.name;
            loadLibraryCategory(seriesFlag,c.id,feedback,adapter);
            ((BaseAdapter)categories.getAdapter()).notifyDataSetChanged();
            grid.requestFocus();
        });
        String selectedKind=isSeries?"series":"movie";
        if(!selectedKind.equals(prefs.getString("last_library_kind","movie"))) selectedMediaCategory="";
        prefs.edit().putString("last_library_kind",selectedKind).apply();
        XtreamClient.Login loginSnapshot=login;
        network.execute(()->{
            try {
                List<XtreamClient.LibraryCategory> list=XtreamClient.loadLibraryCategories(loginSnapshot,isSeries);
                runOnUiThread(()->{
                    if(login!=loginSnapshot||!current.equals(isSeries?SERIES:MOVIES))return;
                    currentCategoryModels.clear();currentCategoryModels.addAll(list);
                    ((BaseAdapter)categories.getAdapter()).notifyDataSetChanged();
                    boolean found=false;for(XtreamClient.LibraryCategory c:list)if(c.id.equals(selectedMediaCategory))found=true;
                    if(!found)selectedMediaCategory="";
                });
            }catch(Exception e){runOnUiThread(()->feedback.setText("Categories unavailable; showing all items"));}
        });
        if(!isSeries && selectedMediaCategory.isEmpty() && !movies.isEmpty()){
            shownLibrary.clear();shownLibrary.addAll(movies);
            feedback.setText(movies.size()+" movies available");adapter.notifyDataSetChanged();
        }else loadLibraryCategory(isSeries,selectedMediaCategory,feedback,adapter);
    }
    private void loadLibraryCategory(boolean isSeries,String cat,TextView feedback,BaseAdapter adapter){
        int token=++generation;
        XtreamClient.Login loginSnapshot=login;
        feedback.setText("Loading library…");shownLibrary.clear();adapter.notifyDataSetChanged();
        network.execute(()->{
            try{
                List<XtreamClient.LibraryItem> result=XtreamClient.loadLibrary(loginSnapshot,isSeries,cat);
                runOnUiThread(()->{
                    if(token!=generation||login!=loginSnapshot||!current.equals(isSeries?SERIES:MOVIES))return;
                    shownLibrary.clear();shownLibrary.addAll(result);
                    feedback.setText(result.size()+" titles  •  Select a poster");adapter.notifyDataSetChanged();
                    if(isSeries&&cat.isEmpty()){series.clear();series.addAll(result);}
                    if(!isSeries&&cat.isEmpty()){movies.clear();movies.addAll(result);}
                });
            }catch(Exception e){runOnUiThread(()->{
                if(token==generation)feedback.setText("Could not load library. Check provider availability.");
            });}
        });
    }
    private void promptLibrarySearch(boolean isSeries){
        EditText search=field("Enter title",false);
        new AlertDialog.Builder(this).setTitle("Search "+(isSeries?"series":"movies"))
            .setView(search).setPositiveButton("Search",(d,which)->{
                currentLibraryQuery=search.getText().toString().trim().toLowerCase(Locale.ROOT);
                List<XtreamClient.LibraryItem> source=isSeries?series:movies;
                if(source.isEmpty()){toast("Open All titles to load the library first");return;}
                shownLibrary.clear();
                for(XtreamClient.LibraryItem item:source)
                    if(currentLibraryQuery.isEmpty()||item.title.toLowerCase(Locale.ROOT).contains(currentLibraryQuery))
                        shownLibrary.add(item);
                screenContent.removeAllViews();
                LinearLayout page=column();screenContent.addView(page);
                page.addView(heading("Search results: "+shownLibrary.size(),21));
                ScrollView scroll=scroll(column());
                LinearLayout results=(LinearLayout)scroll.getChildAt(0);page.addView(scroll);
                for(int i=0;i<Math.min(100,shownLibrary.size());i++){
                    XtreamClient.LibraryItem item=shownLibrary.get(i);
                    TextView b=clickable(item.title,()->openLibraryItem(item));
                    results.addView(b,space(-1,52));verticalGap(results,4);
                }
                page.addView(clickable("Back to library",()->showSection(isSeries?SERIES:MOVIES)));
            }).setNegativeButton("Cancel",null).show();
    }

    private void openLibraryItem(XtreamClient.LibraryItem item){
        selectedLibraryItem=item;
        screenContent.removeAllViews();
        LinearLayout outer=column();outer.setPadding(dp(13),dp(12),dp(13),dp(12));
        screenContent.addView(outer,new FrameLayout.LayoutParams(-1,-1));
        outer.addView(clickable("‹  Back to "+(item.series?"series":"movies"),
            ()->showSection(item.series?SERIES:MOVIES)),space(188,42));
        verticalGap(outer,13);
        LinearLayout body=row();outer.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        ImageView poster=image(R.drawable.hero_movies);images.load(poster,item.poster,R.drawable.hero_movies);
        body.addView(poster,space(205,-1));gap(body,22);
        LinearLayout desc=column();body.addView(desc,new LinearLayout.LayoutParams(0,-1,1));
        TextView title=heading(item.title,27);title.setMaxLines(3);desc.addView(title,space(-1,80));
        TextView subtitle=label(item.series?"SERIES  •  Choose an episode":"MOVIE  •  On demand",16,MUTED,false);
        desc.addView(subtitle,space(-1,37));verticalGap(desc,20);
        String key=(item.series?"series:":"movie:")+item.id;
        desc.addView(clickable(favIds.contains(key)?"★ Remove favourite":"☆ Add to favourites",()->{
            changeFavourite(key);openLibraryItem(item);
        }),space(252,48));verticalGap(desc,10);
        if(item.series){
            desc.addView(clickable("▤  SEE SEASONS & EPISODES",()->openEpisodes(item)),space(283,51));
        }else{
            desc.addView(clickable("▶  PLAY MOVIE",()->playMovie(item)),space(240,53));
            verticalGap(desc,9);
            desc.addView(clickable("⇩  DOWNLOAD FOR OFFLINE",()->downloadMovie(item)),space(283,48));
        }
        TextView note=label("Playback and artwork depend on what your provider supports.",13,MUTED,false);
        desc.addView(note,space(-1,55));
    }
    private void openEpisodes(XtreamClient.LibraryItem item){
        screenContent.removeAllViews();
        LinearLayout parent=column();screenContent.addView(parent,new FrameLayout.LayoutParams(-1,-1));
        parent.addView(clickable("‹ Back to "+item.title,()->openLibraryItem(item)),space(250,47));
        parent.addView(heading(item.title+"  •  Episodes",22),space(-1,50));
        LinearLayout list=column();ScrollView scroll=scroll(list);
        parent.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        list.addView(label("Loading episodes…",16,MUTED,false),space(-1,50));
        XtreamClient.Login currentLogin=login;int token=++generation;
        network.execute(()->{
            try{
                List<XtreamClient.Episode> episodes=XtreamClient.loadEpisodes(currentLogin,item);
                runOnUiThread(()->{
                    if(login!=currentLogin||generation!=token)return;
                    list.removeAllViews();
                    if(episodes.isEmpty())list.addView(label("No episodes returned by your provider",16,MUTED,false));
                    for(XtreamClient.Episode ep:episodes){
                        TextView button=clickable("▶   "+ep.title,()->playEpisode(ep,item));
                        list.addView(button,space(-1,53));verticalGap(list,5);
                    }
                });
            }catch(Exception e){runOnUiThread(()->{
                list.removeAllViews();list.addView(label("Could not load episodes",15,MUTED,false));
            });}
        });
    }
    private void playMovie(XtreamClient.LibraryItem item){
        try{
            String url=XtreamClient.movieUrl(login,item);
            startVideo(url,new WatchHistory.Entry("movie",item.id,item.title,item.poster,item.extension,0,0),0);
        }catch(Exception e){toast("This movie is unavailable");}
    }
    private void playEpisode(XtreamClient.Episode episode,XtreamClient.LibraryItem item){
        startVideo(episode.streamUrl,new WatchHistory.Entry("episode",episode.id,
            item.title+"  •  "+episode.title,item.poster,episode.extension,0,0),0);
    }
    private void startVideo(String url,WatchHistory.Entry entry,long offset){
        if(url==null||!(url.startsWith("http://")||url.startsWith("https://")||url.startsWith("file://"))){
            toast("This title has no valid playback address");return;
        }
        savePlaybackPosition();
        selectedChannel=null;playingHistory=entry;requestedSeekMs=offset;
        try{
            MediaItem.Builder b=new MediaItem.Builder().setUri(url);
            String lower=url.toLowerCase(Locale.ROOT);
            if(lower.contains(".m3u8"))b.setMimeType(MimeTypes.APPLICATION_M3U8);
            else if(lower.contains(".mpd"))b.setMimeType(MimeTypes.APPLICATION_MPD);
            player.setMediaItem(b.build());player.prepare();player.play();enterFullScreen();
        }catch(RuntimeException error){
            playingHistory=null;
            if(fullScreen)leaveFullScreen();
            toast("Unable to open this film; try another title");
        }
    }
    private void resumeHistory(WatchHistory.Entry entry){
        if(login==null){toast("Connect to your provider to resume");return;}
        String url=login.server+(entry.kind.equals("episode")?"/series/":"/movie/")+
            Uri.encode(login.username)+"/"+Uri.encode(login.password)+"/"+entry.id+"."+entry.ext;
        WatchHistory.Entry copy=new WatchHistory.Entry(entry.kind,entry.id,entry.title,entry.poster,
            entry.ext,entry.positionMs,entry.durationMs);
        startVideo(url,copy,entry.positionMs);
    }
    private void savePlaybackPosition(){
        if(playingHistory==null||player==null)return;
        long duration=player.getDuration();long position=player.getCurrentPosition();
        if(duration<=0||duration==androidx.media3.common.C.TIME_UNSET||position<0)return;
        playingHistory.positionMs=position;playingHistory.durationMs=duration;
        if(position>=duration-20000){history.remove(playingHistory.id,playingHistory.kind);return;}
        history.put(playingHistory);
    }
    private void downloadMovie(XtreamClient.LibraryItem item){
        try{
            if(!item.extension.equalsIgnoreCase("mp4")&&!item.extension.equalsIgnoreCase("mkv")){
                toast("Offline downloads support MP4 or MKV files only");return;
            }
            String url=XtreamClient.movieUrl(login,item);
            offline.download(url,item.title,"movie",item.id,item.extension,item.poster,(ok,msg)->runOnUiThread(()->toast(msg)));
            toast("Download started. Open Downloads to see finished items.");
        }catch(Exception e){toast("Could not start download");}
    }

    private void renderHistory(){
        LinearLayout parent=column();screenContent.addView(parent,new FrameLayout.LayoutParams(-1,-1));
        parent.addView(heading("CONTINUE WATCHING",23),space(-1,62));
        List<WatchHistory.Entry> list=history.get();
        if(list.isEmpty()){emptyPage("Your movies and episodes will appear here after you start watching.");return;}
        ScrollView scroll=new ScrollView(this);LinearLayout rows=column();scroll.addView(rows);
        parent.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        for(WatchHistory.Entry e:list){
            LinearLayout row=row();row.setGravity(Gravity.CENTER_VERTICAL);rows.addView(row,space(-1,105));
            ImageView poster=image(R.drawable.hero_movies);images.load(poster,e.poster,R.drawable.hero_movies);
            row.addView(poster,space(104,95));gap(row,12);
            TextView play=clickable("▶  "+e.title+"  •  "+Math.round(e.positionMs/60000.0)+" min watched",()->resumeHistory(e));
            row.addView(play,new LinearLayout.LayoutParams(0,dp(90),1));gap(row,7);
            row.addView(clickable("Remove",()->{history.remove(e.id,e.kind);showSection(CONTINUE);}),space(93,50));
        }
    }
    private void renderFavourites(){
        LinearLayout parent=column();screenContent.addView(parent,new FrameLayout.LayoutParams(-1,-1));
        parent.addView(heading("YOUR FAVOURITES",23),space(-1,58));
        ScrollView scroll=new ScrollView(this);LinearLayout list=column();scroll.addView(list);
        parent.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        boolean found=false;
        for(Channel c:channels)if(favIds.contains(liveId(c))){
            found=true;list.addView(clickable("▣  "+c.name,()->{showSection(LIVE);playLive(c,true);}),space(-1,52));
            verticalGap(list,5);
        }
        for(XtreamClient.LibraryItem it:movies)if(favIds.contains("movie:"+it.id)){
            found=true;list.addView(clickable("▰  "+it.title,()->openLibraryItem(it)),space(-1,52));verticalGap(list,5);
        }
        for(XtreamClient.LibraryItem it:series)if(favIds.contains("series:"+it.id)){
            found=true;list.addView(clickable("▤  "+it.title,()->openLibraryItem(it)),space(-1,52));verticalGap(list,5);
        }
        if(!found)list.addView(label("No favourites yet. Choose ★ on a channel or title.",15,MUTED,false));
    }
    private void renderDownloads(){
        LinearLayout parent=column();screenContent.addView(parent,new FrameLayout.LayoutParams(-1,-1));
        parent.addView(heading("DOWNLOADS",23),space(-1,61));
        TextView intro=label("Offline MP4/MKV videos saved on this Fire Stick. Downloads depend on provider support and available storage.",14,MUTED,false);
        parent.addView(intro,space(-1,65));
        LinearLayout list=column();ScrollView scroll=scroll(list);parent.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        for(OfflineStore.Entry item:offline.list()){
            LinearLayout row=row();row.setGravity(Gravity.CENTER_VERTICAL);list.addView(row,space(-1,61));
            TextView play=clickable("▶  "+item.title,()->{
                File file=offline.fileFor(item);
                if(file.isFile())startVideo(Uri.fromFile(file).toString(),null,0);
                else toast("Downloaded file no longer exists");
            });row.addView(play,new LinearLayout.LayoutParams(0,dp(52),1));gap(row,8);
            row.addView(clickable("Delete",()->{offline.delete(item);showSection(DOWNLOADS);}),space(92,48));
        }
        if(offline.list().isEmpty())list.addView(label("No downloaded videos yet.",15,MUTED,false));
        if(offline.isBusy())list.addView(label("A download is currently running…",14,MUTED,false));
        parent.addView(clickable("Refresh downloads",()->showSection(DOWNLOADS)),space(180,48));
    }
    private void renderSettings(){
        LinearLayout parent=column();parent.setPadding(dp(8),dp(8),dp(12),dp(16));
        screenContent.addView(scroll(parent),new FrameLayout.LayoutParams(-1,-1));
        parent.addView(heading("SETTINGS",23),space(-1,55));
        if(CrashDiagnostics.hasReport(this)){
            parent.addView(clickable("View last crash report",()->{
                new AlertDialog.Builder(this).setTitle("DR TV crash report")
                    .setMessage(CrashDiagnostics.getReport(this))
                    .setPositiveButton("Close",null)
                    .setNeutralButton("Clear report",(d,w)->CrashDiagnostics.clear(this)).show();
            }),space(270,48));verticalGap(parent,9);
        }
        TextView account=label(login==null?"Demo mode":"Connected to "+login.server,16,MUTED,false);
        parent.addView(account,space(-1,46));
        parent.addView(clickable("Change provider / Sign out",()->{
            savePlaybackPosition();player.stop();++generation;login=null;channels.clear();movies.clear();series.clear();
            root=null;showLogin();
        }),space(280,52));verticalGap(parent,9);
        parent.addView(clickable("Forget saved login on this device",()->{
            new AlertDialog.Builder(this).setTitle("Forget your login?")
                .setMessage("Saved DNS, username and password will be cleared. This won't affect your IPTV subscription.")
                .setPositiveButton("Forget",(d,w)->{vault.clear();toast("Saved login cleared");})
                .setNegativeButton("Cancel",null).show();
        }),space(325,52));verticalGap(parent,9);
        parent.addView(clickable("Clear watch history",()->{
            history.clear();toast("Watch history cleared");
        }),space(280,52));verticalGap(parent,9);
        parent.addView(clickable("Load M3U URL",this::promptM3U),space(280,52));verticalGap(parent,9);
        parent.addView(clickable("Open M3U file",this::chooseM3U),space(280,52));verticalGap(parent,9);
        parent.addView(clickable("Back to Home",()->showSection(HOME)),space(280,52));
        verticalGap(parent,14);
        TextView notice=label("DR TV does not include a TV subscription or media. Use only sources you are authorised to access. HTTP DNS connections are not encrypted.",13,MUTED,false);
        notice.setMaxLines(4);parent.addView(notice,space(-1,66));
    }
    private void promptM3U(){
        EditText entry=field("https://provider.example/playlist.m3u",false);
        new AlertDialog.Builder(this).setTitle("Load M3U URL").setView(entry)
            .setPositiveButton("Load",(d,w)->{
                String url=entry.getText().toString().trim();
                if(!url.startsWith("http://")&&!url.startsWith("https://")){toast("Enter an HTTP or HTTPS playlist URL");return;}
                loadM3U(url,null);
            }).setNegativeButton("Cancel",null).show();
    }
    private void chooseM3U(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,PICK_M3U);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==PICK_M3U&&result==RESULT_OK&&data!=null&&data.getData()!=null)
            loadM3U(null,data.getData());
    }
    private void loadM3U(String url,Uri file){
        int token=++generation;
        toast("Loading playlist…");
        network.execute(()->{
            try{
                List<Channel> imported=url!=null?PlaylistLoader.remote(url):
                    PlaylistLoader.document(getApplicationContext(),file);
                runOnUiThread(()->{
                    if(token!=generation)return;
                    channels.clear();channels.addAll(imported);
                    selectedCategory="All channels";showSection(LIVE);
                });
            }catch(Exception e){runOnUiThread(()->toast("Couldn't read that M3U playlist"));}
        });
    }
    private void emptyPage(String message){
        TextView label=label(message,19,MUTED,false);label.setGravity(Gravity.CENTER);
        screenContent.removeAllViews();screenContent.addView(label,new FrameLayout.LayoutParams(-1,-1));
    }

    private void enterFullScreen(){
        if(player.getMediaItemCount()==0){toast("Choose a channel or video first");return;}
        if(fullScreen)return;
        fullScreen=true;
        fullOverlay=new FrameLayout(this);fullOverlay.setBackgroundColor(Color.BLACK);
        root.addView(fullOverlay,new FrameLayout.LayoutParams(-1,-1));
        attachPlayer(fullOverlay);
        fullOverlay.requestFocus();fullOverlay.setFocusableInTouchMode(true);
        fullOverlay.setFocusable(true);
        fullOverlay.setOnClickListener(v->{if(player.isPlaying())player.pause();else player.play();});
        fullOverlay.requestFocus();
    }
    private void leaveFullScreen(){
        if(!fullScreen)return;
        fullScreen=false;savePlaybackPosition();
        if(fullOverlay!=null){
            ViewGroup parent=(ViewGroup)playerView.getParent();if(parent!=null)parent.removeView(playerView);
            root.removeView(fullOverlay);fullOverlay=null;
        }
        if(current.equals(LIVE)&&livePreview!=null)attachPlayer(livePreview);
        else {player.pause();}
        hideBars();
    }
    private void changeChannel(int direction){
        if(channels.isEmpty())return;
        int idx=selectedChannel==null?-1:channels.indexOf(selectedChannel);
        int next=(idx+direction+channels.size())%channels.size();
        playLive(channels.get(next),false);
    }
    @Override public boolean dispatchKeyEvent(KeyEvent e){
        if(e.getAction()==KeyEvent.ACTION_DOWN){
            int key=e.getKeyCode();
            if(fullScreen){
                if(key==KeyEvent.KEYCODE_BACK){leaveFullScreen();return true;}
                if(playingHistory==null&&(key==KeyEvent.KEYCODE_DPAD_UP||key==KeyEvent.KEYCODE_CHANNEL_UP)){
                    changeChannel(-1);return true;
                }
                if(playingHistory==null&&(key==KeyEvent.KEYCODE_DPAD_DOWN||key==KeyEvent.KEYCODE_CHANNEL_DOWN)){
                    changeChannel(1);return true;
                }
                if(playingHistory!=null&&player.isCurrentMediaItemSeekable()&&
                    (key==KeyEvent.KEYCODE_DPAD_LEFT||key==KeyEvent.KEYCODE_DPAD_RIGHT)){
                    player.seekTo(Math.max(0,player.getCurrentPosition()+(key==KeyEvent.KEYCODE_DPAD_RIGHT?10000:-10000)));
                    return true;
                }
                if(key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER||
                    key==KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE){
                    if(player.isPlaying())player.pause();else player.play();return true;
                }
            }
            if(!fullScreen&&key==KeyEvent.KEYCODE_MENU&&root!=null){showSection(SETTINGS);return true;}
        }
        return super.dispatchKeyEvent(e);
    }
    @Override public void onBackPressed(){
        if(fullScreen){leaveFullScreen();return;}
        if(root!=null&&!current.equals(HOME)){showSection(HOME);return;}
        super.onBackPressed();
    }
    @Override protected void onStop(){savePlaybackPosition();if(player!=null)player.pause();super.onStop();}
    @Override protected void onDestroy(){
        ++generation;handler.removeCallbacks(saveTicker);savePlaybackPosition();network.shutdownNow();
        images.shutdown();offline.shutdown();if(playerView!=null)playerView.setPlayer(null);
        if(player!=null)player.release();super.onDestroy();
    }
    @Override public void onConfigurationChanged(Configuration configuration){super.onConfigurationChanged(configuration);}
}
