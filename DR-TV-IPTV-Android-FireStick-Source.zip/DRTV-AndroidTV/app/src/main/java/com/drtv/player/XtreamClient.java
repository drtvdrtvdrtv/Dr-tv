package com.drtv.player;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Minimal Xtream-compatible live TV client.
 * Connections are made directly from the Fire TV to the provider entered by the user.
 * The app does not ship with providers, channels, subscriptions, or credentials.
 * Never log request URLs: the standard Xtream protocol includes credentials in query strings.
 */
public final class XtreamClient {
    private static final int MAX_JSON_BYTES = 24 * 1024 * 1024;
    private static final int MAX_LIVE_CHANNELS = 20_000;

    private XtreamClient() { }

    public static final class Login {
        public final String server;
        public final String username;
        public final String password;

        private Login(String server, String username, String password) {
            this.server = server;
            this.username = username;
            this.password = password;
        }
    }

    public static Login credentials(String inputServer, String inputUser, String inputPassword)
            throws IOException {
        String server = inputServer == null ? "" : inputServer.trim();
        String username = inputUser == null ? "" : inputUser.trim();
        String password = inputPassword == null ? "" : inputPassword;
        if (username.isEmpty() || password.isEmpty()) {
            throw new IOException("Enter both a username and a password");
        }
        if (!server.startsWith("http://") && !server.startsWith("https://")) {
            throw new IOException("Your DNS must start with http:// or https://");
        }
        try {
            URI uri = new URI(server);
            String scheme = uri.getScheme();
            if (uri.getHost() == null || uri.getUserInfo() != null || uri.getRawQuery() != null ||
                uri.getRawFragment() != null || !("https".equalsIgnoreCase(scheme) ||
                "http".equalsIgnoreCase(scheme))) {
                throw new IllegalArgumentException();
            }
            String path = uri.getRawPath();
            if (path != null && !path.isEmpty() && !"/".equals(path)) {
                throw new IOException("Enter only the server DNS and port, without /player_api.php or other paths");
            }
            String normalized = uri.getScheme().toLowerCase(Locale.ROOT) + "://" + uri.getRawAuthority();
            return new Login(normalized, username, password);
        } catch (IOException exception) {
            throw exception;
        } catch (Exception ignored) {
            throw new IOException("Enter a valid server DNS such as http://provider.example:8080");
        }
    }

    public static List<Channel> loadLiveChannels(Login login) throws IOException {
        JSONObject auth = getObject(login, null);
        JSONObject user = auth.optJSONObject("user_info");
        if (user == null || user.optInt("auth", 0) != 1) {
            throw new IOException("Login not accepted. Check the DNS, username and password");
        }
        String status = user.optString("status", "");
        if ("Expired".equalsIgnoreCase(status) || "Disabled".equalsIgnoreCase(status) ||
                "Banned".equalsIgnoreCase(status)) {
            throw new IOException("Your provider reports that this account is " + status.toLowerCase(Locale.ROOT));
        }

        boolean hlsSupported = false;
        JSONArray formats = user.optJSONArray("allowed_output_formats");
        if (formats != null) {
            for (int i = 0; i < formats.length(); i++) {
                if ("m3u8".equalsIgnoreCase(formats.optString(i))) hlsSupported = true;
            }
        }
        // Prefer HLS when the account advertises it; otherwise use MPEG-TS.
        String extension = hlsSupported ? "m3u8" : "ts";
        Map<String, String> categoryNames = new HashMap<>();
        try {
            JSONArray categories = getArray(login, "get_live_categories");
            for (int i = 0; i < categories.length(); i++) {
                JSONObject c = categories.optJSONObject(i);
                if (c == null) continue;
                String id = c.optString("category_id", "");
                String name = c.optString("category_name", "").trim();
                if (!id.isEmpty() && !name.isEmpty()) categoryNames.put(id, name);
            }
        } catch (IOException ignored) {
            // Some otherwise compatible providers don't expose categories.
            // Login can still work: their streams will be grouped under Live TV.
        }

        JSONArray streams = getArray(login, "get_live_streams");
        List<Channel> result = new ArrayList<>(Math.min(streams.length(), MAX_LIVE_CHANNELS));
        String encodedUser = pathSegment(login.username);
        String encodedPassword = pathSegment(login.password);
        for (int i = 0; i < streams.length() && result.size() < MAX_LIVE_CHANNELS; i++) {
            JSONObject stream = streams.optJSONObject(i);
            if (stream == null) continue;
            String streamId = stream.optString("stream_id", "").trim();
            if (!streamId.matches("[0-9]+")) continue;
            String name = stream.optString("name", "").trim();
            if (name.isEmpty()) name = "Live channel " + streamId;
            String categoryId = stream.optString("category_id", "");
            String category = categoryNames.get(categoryId);
            if (category == null) category = "Live TV";
            String streamUrl = login.server + "/live/" + encodedUser + "/" + encodedPassword +
                "/" + streamId + "." + extension;
            result.add(new Channel(name, streamUrl, category,
                stream.optString("stream_icon", ""), stream.optString("epg_channel_id", "")));
        }
        if (result.isEmpty()) throw new IOException("Login succeeded, but no live channels were returned");
        return result;
    }

    private static String query(Login login, String action) {
        String result = login.server + "/player_api.php?username=" + encode(login.username) +
            "&password=" + encode(login.password);
        if (action != null) result += "&action=" + encode(action);
        return result;
    }

    private static JSONObject getObject(Login login, String action) throws IOException {
        try {
            return new JSONObject(readJson(query(login, action)));
        } catch (JSONException ignored) {
            throw new IOException("The provider did not return valid login information");
        }
    }

    private static JSONArray getArray(Login login, String action) throws IOException {
        try {
            return new JSONArray(readJson(query(login, action)));
        } catch (JSONException ignored) {
            throw new IOException("Your provider did not return a valid live TV channel list");
        }
    }

    private static String readJson(String requestUrl) throws IOException {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(requestUrl).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(20000);
            connection.setInstanceFollowRedirects(false); // Don't redirect credentials to another host.
            connection.setRequestProperty("Accept", "application/json, */*");
            connection.setRequestProperty("User-Agent", "DRTV/0.2 (Android TV)");
            int response = connection.getResponseCode();
            if (response == 401 || response == 403) throw new IOException("Provider rejected the login (HTTP " + response + ")");
            if (response < 200 || response >= 300) {
                throw new IOException("Provider server returned HTTP " + response);
            }
            if (connection.getContentLengthLong() > MAX_JSON_BYTES) {
                throw new IOException("Channel list is too large");
            }
            try (InputStream input = connection.getInputStream();
                 ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int total = 0;
                int count;
                while ((count = input.read(buffer)) != -1) {
                    total += count;
                    if (total > MAX_JSON_BYTES) throw new IOException("Channel list is too large");
                    output.write(buffer, 0, count);
                }
                return new String(output.toByteArray(), StandardCharsets.UTF_8);
            }
        } catch (IOException error) {
            // Don't show HttpURLConnection exception details: those could include the URL
            // and therefore the username/password. Only our deliberately safe errors survive.
            String message = error.getMessage();
            if (message != null && (message.startsWith("Provider ") ||
                message.startsWith("Channel list") || message.startsWith("Your provider"))) throw error;
            throw new IOException("Couldn't contact the provider. Check DNS and internet connection");
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static String encode(String value) {
        try { return URLEncoder.encode(value, "UTF-8"); }
        catch (Exception impossible) { throw new IllegalStateException(impossible); }
    }

    private static String pathSegment(String value) {
        return encode(value).replace("+", "%20");
    }
}
