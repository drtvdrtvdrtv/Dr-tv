package com.drtv.player;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Collections;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.TimeZone;
import android.util.Base64;
import android.util.JsonReader;
import android.util.JsonToken;
import java.io.InputStreamReader;
import java.io.FilterInputStream;

/**
 * Minimal Xtream-compatible live TV client.
 * Connections are made directly from the Fire TV to the provider entered by the user.
 * The app does not ship with providers, channels, subscriptions, or credentials.
 * Never log request URLs: the standard Xtream protocol includes credentials in query strings.
 */
public final class XtreamClient {
    private static final int MAX_JSON_BYTES = 24 * 1024 * 1024;
    private static final int MAX_LIVE_CHANNELS = 20_000;
    private static final int MAX_LIBRARY_ITEMS = 12_000;

    private XtreamClient() { }

    public static final class Login {
        public final String server;
        public final String username;
        public final String password;

        private Login(String server, String username, String password) {
            this.server = server;
            this.username = username;
            this.password = password;
        }
    }

    public static Login credentials(String inputServer, String inputUser, String inputPassword)
            throws IOException {
        String server = inputServer == null ? "" : inputServer.trim();
        String username = inputUser == null ? "" : inputUser.trim();
        String password = inputPassword == null ? "" : inputPassword;
        if (username.isEmpty() || password.isEmpty()) {
            throw new IOException("Enter both a username and a password");
        }
        if (!server.startsWith("http://") && !server.startsWith("https://")) {
            throw new IOException("Your DNS must start with http:// or https://");
        }
        try {
            URI uri = new URI(server);
            String scheme = uri.getScheme();
            if (uri.getHost() == null || uri.getUserInfo() != null || uri.getRawQuery() != null ||
                uri.getRawFragment() != null || !("https".equalsIgnoreCase(scheme) ||
                "http".equalsIgnoreCase(scheme))) {
                throw new IllegalArgumentException();
            }
            String path = uri.getRawPath();
            if (path != null && !path.isEmpty() && !"/".equals(path)) {
                throw new IOException("Enter only the server DNS and port, without /player_api.php or other paths");
            }
            String normalized = uri.getScheme().toLowerCase(Locale.ROOT) + "://" + uri.getRawAuthority();
            return new Login(normalized, username, password);
        } catch (IOException exception) {
            throw exception;
        } catch (Exception ignored) {
            throw new IOException("Enter a valid server DNS such as http://provider.example:8080");
        }
    }

    public static List<Channel> loadLiveChannels(Login login) throws IOException {
        JSONObject auth = getObject(login, null);
        JSONObject user = auth.optJSONObject("user_info");
        if (user == null || user.optInt("auth", 0) != 1) {
            throw new IOException("Login not accepted. Check the DNS, username and password");
        }
        String status = user.optString("status", "");
        if ("Expired".equalsIgnoreCase(status) || "Disabled".equalsIgnoreCase(status) ||
                "Banned".equalsIgnoreCase(status)) {
            throw new IOException("Your provider reports that this account is " + status.toLowerCase(Locale.ROOT));
        }

        boolean hlsSupported = false;
        JSONArray formats = user.optJSONArray("allowed_output_formats");
        if (formats != null) {
            for (int i = 0; i < formats.length(); i++) {
                if ("m3u8".equalsIgnoreCase(formats.optString(i))) hlsSupported = true;
            }
        }
        // Prefer HLS when the account advertises it; otherwise use MPEG-TS.
        String extension = hlsSupported ? "m3u8" : "ts";
        Map<String, String> categoryNames = new HashMap<>();
        try {
            JSONArray categories = getArray(login, "get_live_categories");
            for (int i = 0; i < categories.length(); i++) {
                JSONObject c = categories.optJSONObject(i);
                if (c == null) continue;
                String id = c.optString("category_id", "");
                String name = c.optString("category_name", "").trim();
                if (!id.isEmpty() && !name.isEmpty()) categoryNames.put(id, name);
            }
        } catch (IOException ignored) {
            // Some otherwise compatible providers don't expose categories.
            // Login can still work: their streams will be grouped under Live TV.
        }

        JSONArray streams = getArray(login, "get_live_streams");
        List<Channel> result = new ArrayList<>(Math.min(streams.length(), MAX_LIVE_CHANNELS));
        String encodedUser = pathSegment(login.username);
        String encodedPassword = pathSegment(login.password);
        for (int i = 0; i < streams.length() && result.size() < MAX_LIVE_CHANNELS; i++) {
            JSONObject stream = streams.optJSONObject(i);
            if (stream == null) continue;
            String streamId = stream.optString("stream_id", "").trim();
            if (!streamId.matches("[0-9]+")) continue;
            String name = stream.optString("name", "").trim();
            if (name.isEmpty()) name = "Live channel " + streamId;
            String categoryId = stream.optString("category_id", "");
            String category = categoryNames.get(categoryId);
            if (category == null) category = "Live TV";
            String streamUrl = login.server + "/live/" + encodedUser + "/" + encodedPassword +
                "/" + streamId + "." + extension;
            result.add(new Channel(name, streamUrl, category,
                stream.optString("stream_icon", ""), stream.optString("epg_channel_id", "")));
        }
        if (result.isEmpty()) throw new IOException("Login succeeded, but no live channels were returned");
        return result;
    }


    /** A provider-side category. IDs remain strings to accommodate different panels. */
    public static final class LibraryCategory {
        public final String id;
        public final String name;
        LibraryCategory(String id, String name) { this.id = id; this.name = name; }
    }

    /** Film or series listing, without embedded provider credentials. */
    public static final class LibraryItem {
        public final String id;
        public final String title;
        public final String extension;
        public final boolean series;
        public final String poster;
        public final String categoryId;
        LibraryItem(String id, String title, String extension, boolean series, String poster, String categoryId) {
            this.id = id; this.title = title; this.extension = extension; this.series = series;
            this.poster = poster; this.categoryId = categoryId;
        }
    }

    public static final class Episode {
        public final String title;
        public final String streamUrl;
        public final String id;
        public final String extension;
        Episode(String title, String streamUrl, String id, String extension) {
            this.title = title; this.streamUrl = streamUrl; this.id=id; this.extension=extension;
        }
    }

    public static List<LibraryCategory> loadLibraryCategories(Login login, boolean series)
            throws IOException {
        JSONArray list = getArray(login, series ? "get_series_categories" : "get_vod_categories");
        List<LibraryCategory> output = new ArrayList<>();
        output.add(new LibraryCategory("", "All " + (series ? "series" : "movies")));
        for (int i = 0; i < list.length(); i++) {
            JSONObject entry = list.optJSONObject(i);
            if (entry == null) continue;
            String id = entry.optString("category_id", "");
            String name = entry.optString("category_name", "").trim();
            if (id.matches("[0-9]+") && !name.isEmpty()) output.add(new LibraryCategory(id, name));
        }
        return output;
    }

    public static List<LibraryItem> loadLibrary(Login login, boolean series, String categoryId)
            throws IOException {
        String action = series ? "get_series" : "get_vod_streams";
        String extra = categoryId == null || categoryId.isEmpty() ? "" :
            "&category_id=" + numericId(categoryId);
        // Parse large VOD catalogues incrementally. Materialising a multi-MB JSONArray
        // and its string copy at once can exhaust RAM on low-memory Fire Sticks.
        return readLibraryStreaming(query(login, action) + extra, series);
    }


    /** Xtream libraries can include thousands of entries. Stream JSON to keep heap usage small. */
    private static List<LibraryItem> readLibraryStreaming(String requestUrl, boolean series)
            throws IOException {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(requestUrl).openConnection();
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(20000);
            connection.setInstanceFollowRedirects(false); // Protect credentials in Xtream URLs.
            connection.setRequestProperty("Accept", "application/json, */*");
            connection.setRequestProperty("User-Agent", "DRTV/3.0 (Android TV)");
            int response = connection.getResponseCode();
            if (response == 401 || response == 403) throw new IOException("Provider rejected the login (HTTP " + response + ")");
            if (response < 200 || response >= 300)
                throw new IOException("Provider server returned HTTP " + response);
            if (connection.getContentLengthLong() > MAX_JSON_BYTES)
                throw new IOException("Provider movie library is too large");
            List<LibraryItem> output = new ArrayList<>();
            try (InputStream input = new SizeLimitedStream(connection.getInputStream(), MAX_JSON_BYTES);
                 JsonReader reader = new JsonReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
                reader.beginArray();
                while (reader.hasNext() && output.size() < MAX_LIBRARY_ITEMS) {
                    if (reader.peek() != JsonToken.BEGIN_OBJECT) {reader.skipValue();continue;}
                    reader.beginObject();
                    String id="", title="", ext="mp4", icon="", cover="", coverBig="", category="";
                    while(reader.hasNext()) {
                        String name = reader.nextName();
                        switch(name) {
                            case "series_id": if(series)id=readScalar(reader);else reader.skipValue();break;
                            case "stream_id": if(!series)id=readScalar(reader);else reader.skipValue();break;
                            case "name": title=readScalar(reader);break;
                            case "container_extension": ext=readScalar(reader);break;
                            case "stream_icon": icon=readScalar(reader);break;
                            case "cover": cover=readScalar(reader);break;
                            case "cover_big": coverBig=readScalar(reader);break;
                            case "category_id": category=readScalar(reader);break;
                            default:reader.skipValue();
                        }
                    }
                    reader.endObject();
                    if(!id.matches("[0-9]+") || title.trim().isEmpty())continue;
                    String poster=!icon.isEmpty()?icon:(!cover.isEmpty()?cover:coverBig);
                    output.add(new LibraryItem(id,title.trim(),series?"":safeExtension(ext),
                        series,poster,category));
                }
                // We have enough titles for the UI; don't need to allocate the remainder.
                return output;
            }
        } catch (IOException error) {
            String msg=error.getMessage();
            // Exceptions from URL parsing or Android networking can contain credentials.
            if(msg!=null && (msg.startsWith("Provider ") || msg.startsWith("Channel list"))) throw error;
            throw new IOException("Couldn't load the provider library. Check the connection.");
        } finally {if(connection!=null)connection.disconnect();}
    }

    private static String readScalar(JsonReader reader) throws IOException {
        JsonToken type=reader.peek();
        if(type==JsonToken.STRING||type==JsonToken.NUMBER)return reader.nextString();
        if(type==JsonToken.NULL){reader.nextNull();return "";}
        reader.skipValue();return "";
    }

    private static final class SizeLimitedStream extends FilterInputStream {
        private final long max;
        private long bytesRead;
        SizeLimitedStream(InputStream input,long limit){super(input);max=limit;}
        @Override public int read()throws IOException{
            int data=super.read();
            if(data!=-1 && ++bytesRead>max)throw new IOException("Library exceeds size limit");
            return data;
        }
        @Override public int read(byte[] bytes,int off,int len)throws IOException{
            int amount=super.read(bytes,off,len);
            if(amount>0 && (bytesRead+=amount)>max)throw new IOException("Library exceeds size limit");
            return amount;
        }
    }

    public static String movieUrl(Login login, LibraryItem item) throws IOException {
        if (item.series) throw new IOException("Select an episode to play");
        return login.server + "/movie/" + pathSegment(login.username) + "/" +
            pathSegment(login.password) + "/" + numericId(item.id) + "." + item.extension;
    }

    public static List<Episode> loadEpisodes(Login login, LibraryItem series) throws IOException {
        if (!series.series) throw new IOException("Select a series first");
        JSONObject info = getObjectWithExtra(login, "get_series_info", "&series_id=" + numericId(series.id));
        JSONObject seasons = info.optJSONObject("episodes");
        if (seasons == null) return Collections.emptyList();
        List<String> keys = new ArrayList<>();
        java.util.Iterator<String> it = seasons.keys();
        while (it.hasNext()) keys.add(it.next());
        keys.sort((a,b) -> {
            try { return Integer.compare(Integer.parseInt(a), Integer.parseInt(b)); }
            catch (NumberFormatException ignored) { return a.compareTo(b); }
        });
        List<Episode> result = new ArrayList<>();
        for (String key : keys) {
            JSONArray episodes = seasons.optJSONArray(key);
            if (episodes == null) continue;
            for (int j = 0; j < episodes.length() && result.size() < 1200; j++) {
                JSONObject episode = episodes.optJSONObject(j);
                if (episode == null) continue;
                String id = episode.optString("id", "");
                if (!id.matches("[0-9]+")) continue;
                String title = episode.optString("title", "Episode " + (j + 1));
                if (title.trim().isEmpty()) title = "Episode " + (j + 1);
                String ext = safeExtension(episode.optString("container_extension", "mp4"));
                String url = login.server + "/series/" + pathSegment(login.username) + "/" +
                    pathSegment(login.password) + "/" + id + "." + ext;
                result.add(new Episode("Season " + key + "  •  " + title, url, id, ext));
            }
        }
        return result;
    }

    /** Returns channel programme labels for the next several hours. Some panels lack EPG data. */
    public static List<String> shortGuide(Login login, String streamId) throws IOException {
        JSONObject reply = getObjectWithExtra(login, "get_short_epg",
            "&stream_id=" + numericId(streamId) + "&limit=12");
        JSONArray listings = reply.optJSONArray("epg_listings");
        if (listings == null) return Collections.emptyList();
        List<String> result = new ArrayList<>();
        SimpleDateFormat time = new SimpleDateFormat("HH:mm", Locale.getDefault());
        long now = System.currentTimeMillis() / 1000;
        for (int i = 0; i < listings.length() && result.size() < 12; i++) {
            JSONObject item = listings.optJSONObject(i);
            if (item == null) continue;
            long end = item.optLong("stop_timestamp", 0);
            if (end > 0 && end < now) continue;
            long start = item.optLong("start_timestamp", 0);
            String range = (start > 0 ? time.format(new Date(start * 1000)) : "--:--") +
                "–" + (end > 0 ? time.format(new Date(end * 1000)) : "--:--");
            String title = decodeEpgText(item.optString("title", ""));
            if (title.trim().isEmpty()) title = "Programme information unavailable";
            result.add(range + "   " + title);
        }
        return result;
    }

    private static String decodeEpgText(String input) {
        if (input == null || input.isEmpty()) return "";
        try {
            byte[] decoded = Base64.decode(input, Base64.DEFAULT);
            String value = new String(decoded, StandardCharsets.UTF_8);
            if (!value.contains("\uFFFD") && value.chars().noneMatch(ch -> ch < 32 && ch != 10)) return value;
        } catch (IllegalArgumentException ignored) { }
        return input; // Some providers return plain programme titles instead of Base64.
    }

    private static String numericId(String id) throws IOException {
        if (id == null || !id.matches("[0-9]+")) throw new IOException("Invalid provider ID");
        return id;
    }

    private static String safeExtension(String ext) {
        String normalized = ext == null ? "mp4" : ext.toLowerCase(Locale.ROOT);
        return normalized.matches("mp4|mkv|avi|ts|m3u8|mov|webm") ? normalized : "mp4";
    }

    private static JSONObject getObjectWithExtra(Login login, String action, String extra) throws IOException {
        try { return new JSONObject(readJson(query(login, action) + extra)); }
        catch (JSONException ignored) { throw new IOException("Provider returned invalid programme data"); }
    }

    private static JSONArray getArrayWithExtra(Login login, String action, String extra) throws IOException {
        try { return new JSONArray(readJson(query(login, action) + extra)); }
        catch (JSONException ignored) { throw new IOException("Provider returned an invalid library list"); }
    }

    private static String query(Login login, String action) {
        String result = login.server + "/player_api.php?username=" + encode(login.username) +
            "&password=" + encode(login.password);
        if (action != null) result += "&action=" + encode(action);
        return result;
    }

    private static JSONObject getObject(Login login, String action) throws IOException {
        try {
            return new JSONObject(readJson(query(login, action)));
        } catch (JSONException ignored) {
            throw new IOException("The provider did not return valid login information");
        }
    }

    private static JSONArray getArray(Login login, String action) throws IOException {
        try {
            return new JSONArray(readJson(query(login, action)));
        } catch (JSONException ignored) {
            throw new IOException("Your provider did not return a valid live TV channel list");
        }
    }

    private static String readJson(String requestUrl) throws IOException {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(requestUrl).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(20000);
            connection.setInstanceFollowRedirects(false); // Don't redirect credentials to another host.
            connection.setRequestProperty("Accept", "application/json, */*");
            connection.setRequestProperty("User-Agent", "DRTV/0.2 (Android TV)");
            int response = connection.getResponseCode();
            if (response == 401 || response == 403) throw new IOException("Provider rejected the login (HTTP " + response + ")");
            if (response < 200 || response >= 300) {
                throw new IOException("Provider server returned HTTP " + response);
            }
            if (connection.getContentLengthLong() > MAX_JSON_BYTES) {
                throw new IOException("Channel list is too large");
            }
            try (InputStream input = connection.getInputStream();
                 ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int total = 0;
                int count;
                while ((count = input.read(buffer)) != -1) {
                    total += count;
                    if (total > MAX_JSON_BYTES) throw new IOException("Channel list is too large");
                    output.write(buffer, 0, count);
                }
                return new String(output.toByteArray(), StandardCharsets.UTF_8);
            }
        } catch (IOException error) {
            // Don't show HttpURLConnection exception details: those could include the URL
            // and therefore the username/password. Only our deliberately safe errors survive.
            String message = error.getMessage();
            if (message != null && (message.startsWith("Provider ") ||
                message.startsWith("Channel list") || message.startsWith("Your provider"))) throw error;
            throw new IOException("Couldn't contact the provider. Check DNS and internet connection");
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static String encode(String value) {
        try { return URLEncoder.encode(value, "UTF-8"); }
        catch (Exception impossible) { throw new IllegalStateException(impossible); }
    }

    private static String pathSegment(String value) {
        return encode(value).replace("+", "%20");
    }
}
