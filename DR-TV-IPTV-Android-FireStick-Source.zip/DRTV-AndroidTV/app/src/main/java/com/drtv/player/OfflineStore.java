package com.drtv.player;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Downloads compatible direct-file VOD into app-private storage. No source URLs are persisted. */
final class OfflineStore {
    static class Entry {
        final String id, kind, title, filename, poster;
        Entry(String id,String kind,String title,String filename,String poster) {
            this.id=id; this.kind=kind; this.title=title; this.filename=filename; this.poster=poster;
        }
    }
    interface Listener { void result(boolean success, String message); }
    private static final long MAX_BYTES=1_500_000_000L;
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final SharedPreferences prefs;
    private final File folder;
    private volatile boolean busy;
    OfflineStore(Context c) {
        prefs=c.getSharedPreferences("drtv_offline",Context.MODE_PRIVATE);
        folder=new File(c.getFilesDir(),"offline");
        if(!folder.exists()) folder.mkdirs();
    }
    boolean isBusy(){return busy;}
    List<Entry> list(){
        List<Entry> items=new ArrayList<>();
        try {
            JSONArray arr=new JSONArray(prefs.getString("items","[]"));
            for(int i=0;i<arr.length();i++) {
                JSONObject o=arr.optJSONObject(i);
                if(o==null)continue;
                Entry entry=new Entry(o.optString("id"),o.optString("kind"),
                    o.optString("title"),o.optString("file"),o.optString("poster"));
                if(new File(folder,entry.filename).isFile()) items.add(entry);
            }
        }catch(Exception ignored){}
        return items;
    }
    File fileFor(Entry e){ return new File(folder,e.filename); }
    void delete(Entry entry) {
        File file=fileFor(entry);
        if(file.getParentFile().equals(folder)) file.delete();
        List<Entry> entries=list();
        for(int i=entries.size()-1;i>=0;i--)
            if(entries.get(i).filename.equals(entry.filename))entries.remove(i);
        saveList(entries);
    }
    void download(String url,String title,String kind,String id,String ext,String poster,Listener cb){
        if(busy){cb.result(false,"Another download is already running");return;}
        if(!ext.equalsIgnoreCase("mp4") && !ext.equalsIgnoreCase("mkv")) {
            cb.result(false,"Offline downloads currently support MP4 and MKV files only");return;
        }
        if(!url.startsWith("https://") && !url.startsWith("http://")){
            cb.result(false,"Invalid video URL");return;
        }
        busy=true;
        executor.execute(()->{
            HttpURLConnection con=null;
            File partial=null;
            try {
                String fileName=UUID.randomUUID().toString()+"."+ext.toLowerCase();
                partial=new File(folder,fileName+".part");
                File completed=new File(folder,fileName);
                con=(HttpURLConnection)new URL(url).openConnection();
                con.setConnectTimeout(15000); con.setReadTimeout(30000);
                con.setInstanceFollowRedirects(false); // Do not leak credential URLs to redirects.
                int status=con.getResponseCode();
                if(status<200 || status>=300)throw new Exception("Provider returned HTTP "+status);
                if(con.getContentLengthLong()>MAX_BYTES)throw new Exception("File exceeds the 1.5 GB download limit");
                long bytes=0;
                try(InputStream in=con.getInputStream(); FileOutputStream out=new FileOutputStream(partial)){
                    byte[] buf=new byte[32768];int n;
                    while((n=in.read(buf))!=-1){
                        bytes+=n;
                        if(bytes>MAX_BYTES)throw new Exception("File exceeds the download limit");
                        out.write(buf,0,n);
                    }
                }
                if(bytes<1024)throw new Exception("Provider did not send a video file");
                if(!partial.renameTo(completed))throw new Exception("Could not save downloaded video");
                List<Entry> list=list();
                list.add(0,new Entry(id,kind,title,fileName,poster));
                saveList(list);
                cb.result(true,"Downloaded: "+title);
            }catch(Exception ex){
                if(partial!=null)partial.delete();
                String message=ex.getMessage();
                if(message==null || !(message.startsWith("Provider returned HTTP") ||
                    message.startsWith("File exceeds") ||
                    message.startsWith("Could not save") ||
                    message.startsWith("Provider did not send")))
                    message="Download failed; check your connection or provider";
                cb.result(false,message);
            }finally{busy=false;if(con!=null)con.disconnect();}
        });
    }
    private void saveList(List<Entry> items){
        try {
            JSONArray a=new JSONArray();
            for(Entry e:items){
                JSONObject o=new JSONObject();
                o.put("id",e.id);o.put("kind",e.kind);o.put("title",e.title);
                o.put("file",e.filename);o.put("poster",e.poster);a.put(o);
            }
            prefs.edit().putString("items",a.toString()).apply();
        }catch(Exception ignored){}
    }
    void shutdown(){executor.shutdownNow();}
}
