package com.drtv.player;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.widget.ImageView;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Lightweight image loader with an in-memory cache and recycled-view protection. */
final class PosterLoader {
    private final ExecutorService workers = Executors.newFixedThreadPool(3);
    private final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(12 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return value.getByteCount(); }
    };

    void load(ImageView image, String url, int placeholder) {
        image.setImageResource(placeholder);
        image.setTag(url);
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
        Bitmap hit = cache.get(url);
        if (hit != null) { image.setImageBitmap(hit); return; }
        workers.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(url).openConnection();
                connection.setConnectTimeout(7000);
                connection.setReadTimeout(9000);
                connection.setInstanceFollowRedirects(true);
                connection.setRequestProperty("Accept", "image/*");
                if (connection.getResponseCode() / 100 != 2) return;
                if (connection.getContentLengthLong() > 3_000_000) return;
                ByteArrayOutputStream data = new ByteArrayOutputStream();
                try (InputStream in = connection.getInputStream()) {
                    byte[] buffer = new byte[8192]; int n;
                    while ((n = in.read(buffer)) != -1) {
                        if (data.size() + n > 3_000_000) return;
                        data.write(buffer, 0, n);
                    }
                }
                byte[] bytes = data.toByteArray();
                BitmapFactory.Options info = new BitmapFactory.Options();
                info.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(bytes, 0, bytes.length, info);
                if (info.outWidth <= 0 || info.outHeight <= 0) return;
                int sample = 1;
                while (info.outWidth / sample > 720 || info.outHeight / sample > 1080) sample *= 2;
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inSampleSize = sample;
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
                if (bmp == null) return;
                cache.put(url, bmp);
                image.post(() -> { if (url.equals(image.getTag())) image.setImageBitmap(bmp); });
            } catch (Exception ignored) {
                // A missing provider poster should never interrupt browsing or playback.
            } finally { if (connection != null) connection.disconnect(); }
        });
    }

    void shutdown() { workers.shutdownNow(); cache.evictAll(); }
}
