package com.drtv.player;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.widget.ImageView;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.RejectedExecutionException;

/** Memory-bounded artwork loader for low-RAM Android TV / Fire Stick devices. */
final class PosterLoader {
    private final ThreadPoolExecutor workers = new ThreadPoolExecutor(2, 2, 0L,
        TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(48),
        new ThreadPoolExecutor.DiscardOldestPolicy());
    private final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(6 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return value.getByteCount(); }
    };

    void load(ImageView image, String url, int placeholder) {
        image.setImageResource(placeholder);
        image.setTag(url);
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
        Bitmap hit = cache.get(url);
        if (hit != null) { image.setImageBitmap(hit); return; }
        try { workers.execute(() -> {
            HttpURLConnection connection = null;
            try {
                Bitmap cached = cache.get(url);
                if (cached != null) {
                    showIfCurrent(image, url, cached);
                    return;
                }
                connection = (HttpURLConnection) new URL(url).openConnection();
                connection.setConnectTimeout(4500);
                connection.setReadTimeout(6500);
                connection.setInstanceFollowRedirects(true);
                connection.setRequestProperty("Accept", "image/*");
                if (connection.getResponseCode() / 100 != 2) return;
                if (connection.getContentLengthLong() > 4_000_000) return;
                ByteArrayOutputStream data = new ByteArrayOutputStream();
                try (InputStream in = connection.getInputStream()) {
                    byte[] buffer = new byte[8192]; int n;
                    while ((n = in.read(buffer)) != -1) {
                        if (data.size() + n > 4_000_000) return;
                        data.write(buffer, 0, n);
                    }
                }
                byte[] bytes = data.toByteArray();
                BitmapFactory.Options info = new BitmapFactory.Options();
                info.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(bytes, 0, bytes.length, info);
                if (info.outWidth <= 0 || info.outHeight <= 0) return;
                int sample = 1;
                while (info.outWidth / sample > 360 || info.outHeight / sample > 540) sample *= 2;
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inSampleSize = sample;
                opts.inPreferredConfig = Bitmap.Config.RGB_565;
                opts.inDither = true;
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
                if (bmp == null) return;
                cache.put(url, bmp);
                showIfCurrent(image, url, bmp);
            } catch (Exception ignored) {
                // A missing or malformed provider poster must never stop browsing.
            } catch (OutOfMemoryError memoryError) {
                cache.evictAll(); // Give the Fire Stick a chance to recover.
            } finally { if (connection != null) connection.disconnect(); }
        }); } catch (RejectedExecutionException ignored) {
            // An image request arriving after Activity shutdown is harmless.
        }
    }

    private void showIfCurrent(ImageView image, String url, Bitmap bitmap) {
        image.post(() -> {
            if (url.equals(image.getTag()) && image.getWindowToken() != null && !bitmap.isRecycled())
                image.setImageBitmap(bitmap);
        });
    }

    void shutdown() { workers.shutdownNow(); cache.evictAll(); }
}
