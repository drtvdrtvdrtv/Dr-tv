package com.drtv.player;

import android.content.Context;
import android.net.Uri;

import java.io.BufferedReader;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

/** Network/file IO is called off the main thread. */
public final class PlaylistLoader {
    private static final long MAX_BYTES = 16L * 1024L * 1024L;
    private PlaylistLoader() {}

    public static List<Channel> remote(String address) throws IOException {
        URL url = new URL(address);
        String scheme = url.getProtocol();
        if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) {
            throw new IOException("Enter an HTTP or HTTPS playlist URL");
        }
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(12000);
        connection.setReadTimeout(15000);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("Accept", "audio/x-mpegurl, application/x-mpegURL, text/plain, */*");
        connection.setRequestProperty("User-Agent", "DRTV/0.1 (Android)");
        try {
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) throw new IOException("Playlist server returned HTTP " + status);
            if (connection.getContentLengthLong() > MAX_BYTES) throw new IOException("Playlist is too large");
            try (InputStream input = new BoundedInputStream(connection.getInputStream(), MAX_BYTES);
                 BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
                return PlaylistParser.parse(reader, connection.getURL().toString());
            }
        } finally {
            connection.disconnect();
        }
    }

    public static List<Channel> document(Context context, Uri uri) throws IOException {
        InputStream input = context.getContentResolver().openInputStream(uri);
        if (input == null) throw new IOException("Couldn't open the selected file");
        try (InputStream safe = new BoundedInputStream(input, MAX_BYTES);
             BufferedReader reader = new BufferedReader(new InputStreamReader(safe, StandardCharsets.UTF_8))) {
            return PlaylistParser.parse(reader, null);
        }
    }

    public static List<Channel> demo(Context context) throws IOException {
        try (InputStream input = context.getAssets().open("demo.m3u");
             BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            return PlaylistParser.parse(reader, null);
        }
    }

    private static class BoundedInputStream extends FilterInputStream {
        private long bytesRemaining;
        BoundedInputStream(InputStream in, long max) { super(in); this.bytesRemaining = max; }
        @Override public int read() throws IOException {
            if (bytesRemaining <= 0) throw new IOException("Playlist exceeded 16 MB limit");
            int value = super.read();
            if (value != -1) bytesRemaining--;
            return value;
        }
        @Override public int read(byte[] buffer, int offset, int len) throws IOException {
            if (bytesRemaining <= 0) {
                int next = super.read();
                if (next == -1) return -1;
                throw new IOException("Playlist exceeded 16 MB limit");
            }
            int value = in.read(buffer, offset, (int)Math.min(len, bytesRemaining));
            if (value > 0) bytesRemaining -= value;
            return value;
        }
    }
}
