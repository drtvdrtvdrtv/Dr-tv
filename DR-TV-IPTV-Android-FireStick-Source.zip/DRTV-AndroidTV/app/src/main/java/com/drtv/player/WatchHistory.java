package com.drtv.player;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** History stores content IDs and playback positions, never credential-bearing stream URLs. */
final class WatchHistory {
    static final class Entry {
        String kind; // movie, episode
        String id, title, poster, ext;
        long positionMs, durationMs, updated;
        Entry(String kind, String id, String title, String poster, String ext,
              long positionMs, long durationMs) {
            this.kind=kind; this.id=id; this.title=title; this.poster=poster; this.ext=ext;
            this.positionMs=positionMs; this.durationMs=durationMs; updated=System.currentTimeMillis();
        }
        JSONObject toJson() throws Exception {
            JSONObject o=new JSONObject();
            o.put("kind",kind); o.put("id",id); o.put("title",title); o.put("poster",poster);
            o.put("ext",ext); o.put("position",positionMs); o.put("duration",durationMs);
            o.put("updated",updated); return o;
        }
        static Entry fromJson(JSONObject o) {
            Entry e=new Entry(o.optString("kind"),o.optString("id"),o.optString("title"),
                o.optString("poster"),o.optString("ext"),o.optLong("position"),o.optLong("duration"));
            e.updated=o.optLong("updated"); return e;
        }
    }
    private final SharedPreferences prefs;
    WatchHistory(Context ctx) { prefs=ctx.getSharedPreferences("drtv_history",Context.MODE_PRIVATE); }
    List<Entry> get() {
        List<Entry> result=new ArrayList<>();
        try {
            JSONArray arr=new JSONArray(prefs.getString("recent","[]"));
            for(int i=0;i<arr.length();i++) {
                JSONObject o=arr.optJSONObject(i);
                if(o!=null) result.add(Entry.fromJson(o));
            }
        } catch (Exception ignored) { }
        return result;
    }
    void put(Entry e) {
        try {
            List<Entry> entries=get();
            entries.removeIf(item -> item.kind.equals(e.kind) && item.id.equals(e.id));
            entries.add(0,e);
            JSONArray array=new JSONArray();
            for(int i=0;i<Math.min(30,entries.size());i++)array.put(entries.get(i).toJson());
            prefs.edit().putString("recent",array.toString()).apply();
        } catch (Exception ignored) { }
    }
    void remove(String id,String kind) {
        try {
            JSONArray a=new JSONArray();
            for(Entry item:get()) if(!item.id.equals(id)||!item.kind.equals(kind)) a.put(item.toJson());
            prefs.edit().putString("recent",a.toString()).apply();
        } catch(Exception ignored) { }
    }
    void clear(){prefs.edit().remove("recent").apply();}
}
