@echo off
setlocal
cd /d "%~dp0"
set "JAR=gradle\wrapper\gradle-wrapper.jar"
set "EXPECTED=497c8c2a7e5031f6aa847f88104aa80a93532ec32ee17bdb8d1d2f67a194a9c7"
if not exist "%JAR%" (
  echo Downloading official Gradle wrapper from services.gradle.org...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-9.6.0-wrapper.jar' -OutFile '%JAR%'" 
  if errorlevel 1 exit /b 1
)
for /f "delims=" %%H in ('powershell -NoProfile -Command "(Get-FileHash '%JAR%' -Algorithm SHA256).Hash.ToLower()"') do set "ACTUAL=%%H"
if /I not "%ACTUAL%"=="%EXPECTED%" (
  del "%JAR%" >NUL 2>NUL
  echo Wrapper JAR checksum mismatch; file removed.
  exit /b 1
)
java -cp "%JAR%" org.gradle.wrapper.GradleWrapperMain %*
exit /b %ERRORLEVEL%
