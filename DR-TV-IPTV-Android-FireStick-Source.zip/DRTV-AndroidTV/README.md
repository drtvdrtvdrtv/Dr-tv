# DR TV — Version 2 (Fire OS / Android TV)

DR TV is a general-purpose player for *authorised* IPTV playlists and Xtream-compatible live TV services. It **does not supply channels, copyrighted streams, provider accounts, or subscriptions**.

## Version 2 features

- **NEW:** Fire TV remote-friendly **DNS / Xtream login** with three fields: server DNS (including `http://` or `https://`), username and password.
- **NEW:** Sign-in uses the provider's `player_api.php`, then `get_live_categories` and `get_live_streams` APIs to obtain live TV channels.
- **NEW:** Uses HLS (`.m3u8`) if the account advertises it; otherwise live `.ts` streams.
- **NEW:** Press the remote's **MENU** button while browsing to open the login form; it also appears at first launch and at the top of the app.
- Keeps Version 1's M3U URL/file import, categories, favourites, channel search, ExoPlayer preview and full-screen video, and Big Buck Bunny demo.
- Compatible with Android-based Fire OS, including Fire TV Stick HD running Fire OS. **Not** compatible with Vega OS.

## Privacy and security

- Enter credentials **only on your own Fire Stick**. Do not add them to GitHub or send them to anyone in chat.
- Xtream username/password are **kept in memory for the current app session only**. They are not written to SharedPreferences, bundled in the app, or uploaded to GitHub. You'll need to log in again after fully restarting the app.
- **HTTPS** is recommended. HTTP-based provider login is not encrypted; the app shows a warning before using HTTP for the first time.
- The standard Xtream API includes credentials in request URLs; use providers you trust. Avoid public Wi-Fi when using HTTP.
- The current M3U URL feature from Version 1 still saves a playlist URL locally, which might contain a token. This is not encrypted. Prefer Xtream sign-in if available.
- Uses only publicly documented standard Xtream-compatible API endpoints. A particular provider may not support them or may restrict streams/formats.
- Provides **live TV only** for Xtream in this version. VOD, TV series, and an EPG are not included yet.

## Build from your iPhone with the **existing** GitHub workflow

This source ZIP is named **`DR-TV-IPTV-Android-FireStick-Source.zip`**, the same as your Version 1 ZIP, on purpose. It uses the **already-working** GitHub Actions workflow at `.github/workflows/build.yml`.

1. Download this Version 2 source ZIP to your iPhone. Make sure its exact filename is `DR-TV-IPTV-Android-FireStick-Source.zip` (iOS may append a number if an older copy is already in Downloads).
2. In your repo `drtvdrtvdrtv/Dr-tv`, tap **Add file → Upload files** and upload this ZIP **into the repository root**. It must replace the old source ZIP with the **exact same filename**. Don't unzip it first. If GitHub won't replace it, delete the old ZIP through the GitHub file's ellipsis menu and commit, then upload this one.
3. When committed, GitHub should automatically run **Build DR TV for Fire Stick**. If not, open **Actions**, select the workflow and **Run workflow**.
4. Open the successful workflow run and download **DR-TV-FireStick-APK** under **Artifacts**. Extract its ZIP on the iPhone to obtain `DR-TV-FireStick.apk`.
5. Transfer the actual `.apk` (not the artifact ZIP) from iPhone to Fire Stick with LocalSend, as done for Version 1.

### IMPORTANT: Installing Version 2

GitHub's unconfigured debug builds usually use **different signing keys** on different runners, so Android may say **App not installed** if you try to install Version 2 over Version 1. To avoid this, **uninstall Version 1 before installing Version 2**: Fire Stick → Settings → Applications → Manage Installed Applications → DR TV → Uninstall. This deletes Version 1 local favourites, playlist settings and app data.

## How to sign in

1. Open DR TV Version 2. On first launch the Xtream login form appears. Later select **LOGIN WITH DNS / XTREAM** or press remote **MENU** while browsing.
2. In **DNS**, enter just your provider's server address and port, for example `http://example.com:8080` (not `player_api.php`).
3. Enter your username and password **on the Fire Stick**.
4. Select **Connect**. If HTTP is used, read the warning and confirm only if you trust the provider.
5. Wait for live categories and channels to load, then navigate with remote D-pad and press OK on a channel to play it.
6. The **Refresh** button reloads the currently connected Xtream session until the app is shut down.

If sign-in fails, first verify all three values and whether your IPTV provider supports Xtream Codes `player_api.php` logins. A DNS address alone is not enough without a compatible service.

## Source structure

- `app/src/main/java/com/drtv/player/XtreamClient.java` — validates server, queries API, maps live categories and channels.
- `app/src/main/java/com/drtv/player/MainActivity.java` — Fire TV login dialog, browsing and video UI.
- `app/src/main/java/com/drtv/player/PlaylistLoader.java` and `PlaylistParser.java` — existing M3U support.
- `app/src/main/assets/demo.m3u` — legal demo stream.
- `app/build.gradle.kts` — package `com.drtv.player`, versionCode `2`, versionName `0.2.0`.

## Verification

Java M3U parser smoke tests run with `bash scripts/test_parser.sh` and pass. Xtream client Java syntax was checked with a local `javac` compile using minimal JSON API type stubs. The **Android V2 APK is not compiled or tested yet**; compile it using the existing working GitHub Actions workflow and test on your Fire Stick. Since each Xtream server can behave differently, provider-specific playback is not guaranteed.
