# DR TV Premium — Stability Update 3.0.1 for Android & Fire Stick HD

A full Android / Fire OS **source-code project** for a remote-controlled IPTV player. Uses the approved DR TV red-and-black design as its visual reference, with the same three illustrated Live TV / Movies / Series hero tiles, branded top bar, sidebar navigation and poster rows. Provider-supplied titles and images replace the **illustrative** film artwork shown in the concept.

**Status:** Stability-fix source created; **this update has not yet been compiled or tested on the Fire Stick**. Do not remove the existing working DR TV V2 until you have tested this build. Exact cross-device layout and compatibility still need real-device validation.

## Version 3.0.1 fixes (movie browsing)

After a Fire Stick HD test revealed that some movie posters did not respond to the remote and the app later closed unexpectedly, this update focuses on stability:

- **Remote focus / OK:** movie grid poster views no longer steal focus from the GridView; the GridView owns selection and OK clicks.
- **Recycled poster cells:** reuse views instead of allocating fresh image views for every grid scroll.
- **Less memory pressure:** limit parallel artwork requests and queue depth, decode to smaller RGB_565 bitmaps, and use a 6 MB artwork cache. Large libraries are parsed incrementally instead of materialising the entire JSON array in memory.
- **Better playback failures:** a film that cannot load displays a usable error dialog and returns from fullscreen rather than appearing to hang.
- **On-device crash diagnostics:** Settings → **View last crash report** appears if a crash was recorded. The report contains exception type and source frame names, **not** your IPTV address, username, password, or stream URLs. Screenshot that screen if a crash returns.
- No changes to the approved red-and-black artwork, Remember me feature, core login, or live channel UI.

These changes address likely causes but **do not prove the precise cause of the previous crash** without its system crash log. Build success and real Fire Stick testing are still required.

## Main features

- **Login always opens first.** Enter DNS/server URL, Xtream username and password. Tap **Remember me** to encrypt all three values locally using AES-GCM with a non-exportable Android Keystore key. On subsequent launches the login screen opens with the saved information filled in; press **Connect**. Uncheck Remember me on sign-in, or use Settings > Forget saved login, to clear it. The app never uploads your credentials to GitHub or its developers.
- **Home page** themed directly from the approved concept, using matching DR TV logo art, animated? **No** — static illustrations for the three navigational hero tiles, live clock, continue-watching row and actual provider-supplied movie posters.
- **Live TV** Xtream categories, channel search, favourites, video playback, fullscreen and remote up/down channel switching.
- **TV Guide** fetches programme listings for a selected live channel using Xtream `get_short_epg`. This is a per-channel guide, **not a full multi-channel grid**.
- **Movies** browse categories and poster grids; open a title and play using Media3 ExoPlayer.
- **Series** browse show categories, select a series, then its episodes and watch.
- **Continue Watching** saves VOD playback progress locally, keyed by content ID rather than stream URL, and can resume movies and episodes after relaunch.
- **Favourites** stores selected channels, movies and series on the Fire Stick.
- **Downloads** can save provider-supported direct MP4/MKV movie files in app-private local storage, with an enforced 1.5 GB per-video limit. It cannot download HLS playlists, protected/DRM content or unsupported formats. Providers may prohibit offline downloads.
- **Settings** allows changing provider, forgetting saved login, clearing watch history, importing an M3U URL/file, and going home.
- **Demo** plays an authorised sample video without provider credentials for player testing.

## Important design facts

The concept's film posters, actors, logos and suggested viewing progress are illustration only; they are **not included** as a bundled catalogue. The app displays movies, titles, cover images, categories, guide data and episodes **only** if returned by the user-configured provider, and only from streams the user has permission to watch. The three illustrated navigation tiles and decorative DR TV header artwork are derived from the user-approved image. Reference screenshot: `docs/approved-design-concept.png`.

## Android requirements

- Target: **Fire TV Stick HD running Fire OS**, or Android TV devices that support Android APKs.
- `compileSdk=36`, `targetSdk=35`, `minSdk=23`, Java 17, Android Gradle Plugin 9.5.0, Gradle 9.6.0, Media3 1.11.1.
- Landscape interface with D-pad/OK/Back/Menu navigation.
- **Different application ID:** `com.drtv.premium` / label `DR TV Premium`, so it installs alongside your existing DR TV V2 during testing instead of removing your working player. **Do not uninstall V2 first.**

## Build from your iPhone using the existing GitHub setup

Your GitHub Actions workflow is already configured in `drtvdrtvdrtv/Dr-tv` to unzip a specific source ZIP and run Gradle. This source is packaged to fit that workflow.

1. Download `DR-TV-IPTV-Android-FireStick-Source.zip` to the **Files** app. **Do not unzip** this source ZIP.
2. If you have another download with the same filename on the iPhone, **move or rename the older one first**.
3. Open your repository on GitHub in Safari. Upload this new ZIP to the repository root, replacing the old `DR-TV-IPTV-Android-FireStick-Source.zip`, and commit it. Your existing `.github/workflows/build.yml` will run.
4. Open the latest **Build DR TV for Fire Stick** Actions run; only download the `DR-TV-FireStick-APK` artifact if the build has a green success tick.
5. Unzip the **artifact ZIP** on iPhone to obtain `DR-TV-FireStick.apk` (this is different from the source ZIP).
6. Send **only the APK** to the Fire Stick using LocalSend. Choose **Package Installer → Just Once → Install**.
7. Open **DR TV Premium** and test the login, menus, Live TV, movies, series and programme guide with a provider you are authorised to use.

If you want later builds to update this exact Premium installation without uninstalling, configure a **persistent, private Android signing key** for GitHub Actions. Without it, debug APKs built on separate runners can be signed with different keys and Android may refuse to install an update. Do not put your signing key in a public repository.

## Remote controls

- **D-pad** navigate between red-highlighted menu items and tiles.
- **OK** open a menu, play a selected channel, or enter fullscreen. In fullscreen OK pauses/resumes.
- **Back** exits fullscreen or returns to Home.
- **Live fullscreen:** Up/Down changes channel.
- **Movie/episode fullscreen:** Left/Right seeks backwards/forwards by 10 seconds when supported.
- **Menu key** opens Settings while browsing.

## Privacy and network security

- The saved **Remember me** login is encrypted using AES-GCM and Android Keystore; `allowBackup=false` prevents normal Android backup of credentials.
- Actual Xtream login calls go directly from the Fire Stick to your server, not through ChatGPT. The Xtream API includes credentials in request URLs by design. **HTTPS is preferable**; if your DNS uses plain HTTP the connection is not encrypted.
- HTTP redirects of Xtream login requests are disabled to reduce the risk of credentials being sent to unintended hosts. Network exception messages are sanitised.
- Watch history stores content IDs/metadata, not stream URLs. Downloads are stored in app-private files.
- No provider credentials are bundled. Never commit real DNS, username, password or tokens to GitHub.

## Installing this stability update

The new APK has application ID `com.drtv.premium`, the same as your previous Premium build, and version code 5. Android may refuse the update if a new GitHub runner signed the APK with a different temporary debug key. If you see **App not installed**, uninstall **DR TV Premium only** (not **DR TV** / V2) and install this latest APK. This may reset saved Premium credentials, favourites and history. **Never put credentials in GitHub.** A persistent private signing key for future builds avoids this problem.

## Test status and limitations

- Java syntax parsing: **passed** for all source files.
- Existing six M3U parser smoke checks: **passed**.
- New credential storage, Fire Stick focus, UI rendering, provider compatibility and player paths still require **APK build and on-device testing**. A green CI build confirms compilation, **not** flawless playback.
- Not all Xtream-compatible providers implement movies, series, guide or direct-file downloads consistently. Some streams require a different container or codec.
- This is an original working-code implementation designed to match the approved visual concept; **not a claim of pixel-perfect rendering at every TV screen size**.
