# DR TV — Android & Fire TV IPTV player (MVP)

A real native Android Studio **source project** for an IPTV/M3U video player, designed for Android-based Fire TV Sticks and Android TV/phones in landscape mode. The project does **not** contain copyrighted channels, a paid IPTV service, or any service credentials.

## What version 0.1 does

- Runs in the Fire TV/Android TV launcher and accepts D-pad/OK remote navigation.
- Adds an HTTP(S) M3U playlist by URL, or imports a local `.m3u` file through Android's document picker.
- Parses `#EXTINF` titles, `group-title`, `#EXTGRP`, `tvg-id`, `tvg-logo`; supports large playlists (up to 20,000 entries).
- Shows categories, filters channels, searches channel names and groups.
- Plays HLS `.m3u8`, DASH `.mpd`, and common progressive streams via AndroidX Media3 ExoPlayer.
- Lets you add/remove favourites and automatically reloads the last playlist (where document permission is still valid).
- Offers embedded preview, full-screen video, channel up/down and OK play/pause, plus a legal demo HLS stream.
- Uses DR TV red/black branding.

## How to build the APK

1. On a Windows, macOS, or Linux computer, install the **latest Android Studio** (with Android SDK 36 and JDK 17).
2. Unzip the downloaded project. In a terminal inside **DRTV-AndroidTV**, run `./gradlew help` on macOS/Linux or `gradlew.bat help` on Windows **once before opening the project**. This safely downloads the official Gradle wrapper JAR and validates its SHA-256 hash. You need internet access and Java 17 in PATH for this first step.
3. Open the **DRTV-AndroidTV** folder in Android Studio; let Gradle sync and download dependencies. The project uses AGP 9.5.0, Gradle 9.6.0 and Media3 1.11.1.
4. In Android Studio select **Build → Build App Bundle(s) / APK(s) → Build APK(s)** (menu wording varies by Android Studio version).
5. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.
6. Install it on a compatible Android-based Fire TV Stick or Android phone/tablet. Developer options/ADB or an authorised sideloading method may be needed on a Fire TV device. You can test first with an Android TV emulator.

On macOS/Linux you can also run `./gradlew assembleDebug` at the project root. On Windows run `gradlew.bat assembleDebug`.

## How to use it

- **Demo**: Loads the bundled `demo.m3u` with a public Big Buck Bunny HLS test stream (network connection needed).
- **+ Add M3U URL**: Enter a playlist you are authorised to use; tap Load.
- **Open M3U file**: Use Android's file picker to choose your local playlist.
- **Categories**: Move through groups using remote arrows; OK selects.
- **Channels**: Press OK on a channel to play it. Press OK on the *same* playing channel again, or highlight **Full screen**, to expand.
- **In full screen**: Up/down changes channel, OK toggles pause/play, Back returns to browsing.
- **☆ Favourite**: Add/remove the current channel, then see it under **★ Favourites**.

## Compatibility note (important)

This is an **Android APK**, not an app for Fire TV devices based on **Vega OS**. Some newer Fire TV models (including the 2025 Fire TV Stick 4K Select and some 2026 devices) use Vega OS, which does not accept Android APKs. Check your exact model before trying to install. `minSdk=23` means Android 6.0+ / Fire OS 6+; it does not target old Fire OS 5 sticks.

## Limitations / next build

- No Xtream Codes login in this MVP. No XMLTV EPG, VOD episode browser, PIN-protected profiles, custom headers/cookies, or DRM.
- Stream URLs without known `.m3u8` or `.mpd` extension may need explicit MIME-type handling if the server uses HLS/DASH; not all proprietary formats/codecs will play on every device.
- The source URL is saved in app-private Android SharedPreferences to reopen after relaunch. An M3U URL may contain credentials/token query parameters; do not share project exports or screenshots showing them. For production, use encrypted credential storage, domain allowlisting where appropriate, clear-text HTTP opt-in, playlist management, and a full security/privacy review.
- Cleartext HTTP is enabled because some legacy IPTV playlists and streams require it. Prefer HTTPS links when available.
- Local files must contain absolute HTTP(S) stream URLs; relative local file paths aren't playable.
- Sample media availability is controlled by its host and may change.
- We ran `scripts/test_parser.sh` and validated the Java M3U parser; **we have not compiled an Android APK or run this app on a Fire TV device in this environment**. Android Studio/device testing is still required.

## Project structure

```text
app/src/main/java/com/drtv/player/
  MainActivity.java     Full TV-first interface, D-pad keys, ExoPlayer setup
  Channel.java          Channel model and hashed favourite key
  PlaylistParser.java   Extended-M3U parser
  PlaylistLoader.java   Safe bounded playlist HTTP/file loading
app/src/main/assets/demo.m3u
app/src/main/AndroidManifest.xml
app/build.gradle.kts
```

## Legal

DR TV is a **general-purpose media player**. Use M3U playlists and streams that you own or have permission to access. It does not provide channels or IPTV subscriptions.
