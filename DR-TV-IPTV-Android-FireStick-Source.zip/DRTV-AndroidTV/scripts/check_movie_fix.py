#!/usr/bin/env python3
from pathlib import Path
base = Path(__file__).resolve().parents[1] / 'app/src/main/java/com/drtv/player'
a = (base / 'MainActivity.java').read_text()
b = (base / 'PosterLoader.java').read_text()
c = (base / 'XtreamClient.java').read_text()
d = (base / 'CrashDiagnostics.java').read_text()
checks = {
    'grid delegated click': 'grid.setOnItemClickListener' in a and 'tile.setFocusable(false);' in a,
    'recycled grid cells': 'convert instanceof FrameLayout' in a,
    'playback error dialog': 'Unable to play this title' in a,
    'bounded image queue': 'new ArrayBlockingQueue<>(48)' in b,
    'poster size limiting': 'Bitmap.Config.RGB_565' in b,
    'streaming library JSON': 'JsonReader reader' in c and 'readLibraryStreaming' in c,
    'credential-free crash report': 'getClassName()' in d and 'getLineNumber()' in d and 'getMessage()' not in d,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
assert all(checks.values())
