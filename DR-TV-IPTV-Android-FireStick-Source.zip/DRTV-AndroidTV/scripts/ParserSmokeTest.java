import com.drtv.player.Channel;
import com.drtv.player.PlaylistParser;
import java.io.BufferedReader;
import java.io.StringReader;
import java.util.List;

public class ParserSmokeTest {
    public static void main(String[] args) throws Exception {
        String playlist = "#EXTM3U\n"
                + "#EXTINF:-1 tvg-logo=\"https://image.example/a.png\" group-title=\"News\" tvg-id=\"news-1\",Good, Morning News\n"
                + "https://media.example/news.m3u8\n"
                + "#EXTINF:-1,Second stream\n"
                + "#EXTGRP:Sport\n"
                + "https://media.example/sports.mpd\n"
                + "#EXTINF:-1,Relative\nrelative.ts\n"
                + "#EXTINF:-1,Evil\nfile:///etc/passwd\n";
        List<Channel> channels = PlaylistParser.parse(new BufferedReader(new StringReader(playlist)), "https://media.example/playlist/main.m3u");
        require(channels.size() == 3, "expected 3 allowed entries: " + channels.size());
        require(channels.get(0).name.equals("Good, Morning News"), "display name with comma");
        require(channels.get(0).group.equals("News"), "group attribute");
        require(channels.get(1).group.equals("Sport"), "EXTGRP");
        require(channels.get(2).streamUrl.equals("https://media.example/playlist/relative.ts"), "relative resolution");
        require(channels.get(0).key.length() == 64, "hashed IDs");
        System.out.println("PASS: 6 playlist parsing checks");
    }
    static void require(boolean condition, String description) {
        if (!condition) throw new IllegalStateException(description);
    }
}
