#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
out="$(mktemp -d)"
trap 'rm -rf "$out"' EXIT
javac -d "$out" app/src/main/java/com/drtv/player/Channel.java app/src/main/java/com/drtv/player/PlaylistParser.java scripts/ParserSmokeTest.java
java -cp "$out" ParserSmokeTest
