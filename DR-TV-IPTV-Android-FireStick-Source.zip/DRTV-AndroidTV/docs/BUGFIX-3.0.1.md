# DR TV Premium 3.0.1 — Fire Stick movie stability

**Report:** Several movies did not respond to OK; one played; subsequent browsing closed the app.

## Implemented safeguards

1. Movie grid D-pad selection is now owned by GridView rather than focusable poster tiles. Reuses grid tiles via convertView.
2. Bitmap RAM consumption reduced via 360×540 sample bounds and RGB_565, 6MB cache, 2 download workers and a 48-request queue.
3. The large Xtream movie/series JSON array is parsed with Android JsonReader rather than building an oversized JSONArray and a full duplicate string in memory.
4. Playback errors now display an explanation and technical error code and return to movie details instead of leaving fullscreen in an unusable state.
5. A privacy-safe crash report is recorded on-device, viewable under Settings after relaunch.

**Evidence:** We have not obtained a Fire Stick system crash log; none of these fixes can yet be confirmed as the precise cause of the earlier unexpected exit. Do not claim the APK is fixed without testing several movies and a long scrolling session on the affected device.

## Test procedure

- Install V3.0.1 and sign into your authorised content provider.
- Open Movies, move around using the remote, and click at least ten different poster tiles (including ones that did not respond earlier).
- Open a movie; confirm full-screen video starts. Press Back; confirm you can choose another title.
- Test one unavailable title: failure should show a dialog, not exit the app.
- Browse/scroll movies for several minutes.
- If the app exits, relaunch, go to Settings > View last crash report, and capture the screen (do not share private credentials).

This patch retains the same app ID as Premium. A GitHub Actions debug APK may have a different signing key and require uninstalling the previous Premium app before installation. Do not uninstall the working DR TV V2.
