# DR TV Premium build & test checklist

- [ ] GitHub workflow build passes with green check
- [ ] APK installs on Fire Stick HD as **DR TV Premium** without removing DR TV V2
- [ ] On every cold launch, login screen appears first
- [ ] Wrong DNS / username / password shows safe error, no crashes
- [ ] Correct Xtream login loads live channels and categories
- [ ] Check **Remember me**, close and reopen app, verify DNS/user/password prefilled and connection works
- [ ] Uncheck Remember me, reconnect, close and reopen, verify fields are not prefilled
- [ ] Channels work in preview and fullscreen, Back returns to list, Up/Down changes live channel
- [ ] TV Guide shows schedule when provider supports `get_short_epg`
- [ ] Movies and Series categories load; poster image fallback looks correct
- [ ] Movie plays, Back exits fullscreen, resume history works after reopening
- [ ] Episode plays, returning to list works
- [ ] Favourites survive relaunch
- [ ] MP4/MKV offline download works if provider authorises download; deletes successfully
- [ ] Navigation with only the Fire Stick remote; no keyboard or touch required except typing credentials
- [ ] Turn off provider internet temporarily: app shows failure without crashing
- [ ] Never upload screenshots containing your DNS/password, or check those details into GitHub
