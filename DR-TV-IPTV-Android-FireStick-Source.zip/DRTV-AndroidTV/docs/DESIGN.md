# Approved DR TV screen design

Visual reference: `approved-design-concept.png` (the image approved in this chat).

## Theme

- Near-black background `#08080B`
- Dark panels `#111217`, dark card surface `#18191F`
- DR TV red `#EB141E`
- Primary white `#FFFFFF`; muted copy `#A8A9B0`
- Rounded tile edges and red/white focus outline for TV remotes

## Home screen

- Left menu (~19.5% of available width): Home, Live TV, TV Guide, Movies, Series, Favourites, Continue Watching, Downloads, Settings
- Header: same DR TV graphic from concept, skull header image, utility actions and live time/date
- Three illustrated 16:9-esque hero navigation tiles, same crops as approved visual
- Continue Watching: actual saved watch history, not the sample titles shown in the visual reference
- Popular Movies: actual provider-supplied posters, not hard-coded copyrighted poster assets

## Login screen

- Shown every time DR TV launches, before the player/home UI
- Server/DNS, Username, Password
- Remember me checkbox: opt-in AES-GCM encryption through Android Keystore
- Connect; Try Demo for player test; messages for incorrect login and connectivity errors

## TV remote

Every navigation element is a native focusable view. Selected navigation entries have solid red backgrounds; focused entries have red backgrounds with a white border. No cursor/mouse is required for normal browsing.

## Known differences from a still image

A still image can show fabricated film titles, profile notifications, downloads and progress. The actual app must take data from the user's provider, local viewing history and downloads; empty states are shown instead of fake items. Content scrolls naturally, and title lengths/posters vary. Provider video formats and access permissions may vary.
